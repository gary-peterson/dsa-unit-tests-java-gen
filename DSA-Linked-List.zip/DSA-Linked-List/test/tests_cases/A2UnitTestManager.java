package tests_cases;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import linearpub.DynamicList;
import linearpub.LinkedListFactory;
import scorer.AbstractScorer;
import scorer.TestSpec;
import unit_test.unit_test_model.UnitTestManager;

public class A2UnitTestManager extends UnitTestManager {
	
	//--------------------------------------------------------
	
	public A2UnitTestManager() {
		this(false);
	}	
	
	public A2UnitTestManager(boolean aShouldScore) {
		super(aShouldScore);
	}
	
	//--------------------------------------------------------

	@Override	
	public List<Class<?>> testCases() {
		List<Class<?>> list = new ArrayList<>();
		list.add(DynamicList_EmptyList_TestCase.class);
		list.add(DynamicList_OneElement_TestCase.class);
		list.add(DynamicList_ManyElements_TestCase.class);
		list.add(DynamicList_AddingInserting_TestCase.class);
		list.add(DynamicList_Removing_TestCase.class);
		list.add(DynamicList_LoadTests_TestCase.class);		
		return list;
	}	

	@Override	
	public List<String> testCaseNames() {
		return testCases().stream()
			.map(testCase -> testCase.getSimpleName())
			.collect(Collectors.toList());
	}

	private static <T> Supplier<DynamicList<T>> emptyLLGenerator() {
		return () -> LinkedListFactory.newList();
	}
	
	private static String constructLLUnitSnippet() {
		return "LinkedListFactory.newList()";
	}

	@SuppressWarnings("unchecked")
	@Override
	public AbstractScorer<TestSpec> newTestCase(Class<?> testCase) throws Exception {
		Constructor<?> constructor;
		Abstract_DynamicList_TestCase<TestSpec> scorer;		
		constructor = testCase.getConstructor();
		scorer = (Abstract_DynamicList_TestCase<TestSpec>)constructor.newInstance();			
		scorer.setConstructUnitSnippet(constructLLUnitSnippet());
		scorer.setEmptyListGenerator(emptyLLGenerator());
		return scorer;
	}	

	//---------------------------------------------------------------
	//Run All
	
	public void runAll() {
		run(this.testCaseNames(), new ArrayList<>());
	}
	
	public static void runAllTestCases(boolean b) {
		A2UnitTestManager mgr = new A2UnitTestManager(b);
		mgr.setHeadfull(false);
		mgr.runAll();
	}	
	
	public static void main(String[] args) {
		String[] array = args;
		array = new String[]{"y"};
		A2UnitTestManager.runAllTestCases(array.length > 0 ? array[0].toLowerCase().equals("y") : false);
	}
	
}
