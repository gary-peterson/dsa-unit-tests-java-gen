package tests_cases;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import linearpub.DynamicList;
import linearpub.LinkedListFactory;
import scorer.AbstractScorer;
import scorer.AssignmentScorer;
import scorer.PreDiagnostics;
import scorer.ScorerLauncher;
import scorer.TestSpec;

public class DSAA2Scorer extends ScorerLauncher {

	public static void main(String[] args) {
		//(new Assignment3Scorer()).go(args);
		(new DSAA2Scorer()).go("90sdf89a7z");
	}

	protected AssignmentScorer newScorer() {

		PreDiagnostics preDiagnostics = new PreDiagnostics(
				"Linked List", 
				Arrays.asList("linearpub.DynamicList"),
				Arrays.asList("linearpub.LinkedListFactory"));
		preDiagnostics.go();

		AssignmentScorer scorer;
		List<AbstractScorer<TestSpec>> scorers = new ArrayList<>();

		scorers.add(new DynamicList_EmptyList_TestCase(17, emptyLLGenerator(), constructLLUnitSnippet()));
		scorers.add(new DynamicList_OneElement_TestCase(17, emptyLLGenerator(), constructLLUnitSnippet()));		
		scorers.add(new DynamicList_ManyElements_TestCase(17, emptyLLGenerator(), constructLLUnitSnippet()));
		scorers.add(new DynamicList_AddingInserting_TestCase(17, emptyLLGenerator(), constructLLUnitSnippet()));
		scorers.add(new DynamicList_Removing_TestCase(17, emptyLLGenerator(), constructLLUnitSnippet()));	
		scorers.add(new DynamicList_LoadTests_TestCase(15, emptyLLGenerator(), constructLLUnitSnippet()));		
		
		scorer = new AssignmentScorer("A2", 100, scorers);

		return scorer;
	}

	private static <T> Supplier<DynamicList<T>> emptyLLGenerator() {
		return () -> LinkedListFactory.newList();
	}
	
	private static String constructLLUnitSnippet() {
		return "LinkedListFactory.newList()";
	}	

}
