package tests_cases;

import java.util.function.Supplier;

import linearpub.DynamicList;
import linearpub.LinkedListFactory;
import testutil.Thing;

public class _UnitTestManager {
	
	public static <T> DynamicListTestSuite<T> newTestSuite() {
		DynamicListTestSuite<T> suite;
		suite = new DynamicListTestSuite<>(emptyListGenerator(), constructLLUnitSnippet());
		return suite;
	}
	
	public static <T> DynamicListTestSuite<T> newTestSuiteWithScoring() {
		DynamicListTestSuite<T> suite;
		suite = new DynamicListTestSuite<>(emptyListGenerator(), constructLLUnitSnippet());
		suite.setShouldScore(true);
		return suite;
	}	
	
	//----------------------------

	public static void main(String[] args) {
		DynamicListTestSuite<Thing> suite;
		suite = new DynamicListTestSuite<>(emptyListGenerator(), constructLLUnitSnippet());
		//String[] array = args;
		String[] array = new String[] { "y" };
		boolean shouldScore = array.length > 0 ? array[0].toLowerCase().equals("y") : false;
		suite.runAll(false, shouldScore);
	}

	private static <T> Supplier<DynamicList<T>> emptyListGenerator() {
		return () -> LinkedListFactory.newList();
	}

	private static String constructLLUnitSnippet() {
		return "LinkedListFactory.newList()";
	}
}
