
java -cp "src;test;scorerbase.jar" tests_cases.A2UnitTestManager

read -p "Press enter to continue"
