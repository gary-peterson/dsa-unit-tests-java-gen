package pub;

/*
	Class: SSFactory.java
	Description:
		Specialized structure factory.
*/

import ss.Bag;
import ss.Deque;
import ss.Queue;
import ss.Stack;

public class SSFactory {

	//---------------------------------------------------------
	//Generate Stacks (one linked, one arrayed)
	
	public static <T> StackIdea<T> newLinkedStack() {
		Stack<T> struc = new Stack<>();
		struc.setLinked();
		return struc;
	}
	
	public static <T> StackIdea<T> newArrayedStack() {
		Stack<T> struc = new Stack<>();
		struc.setArrayed();
		return struc;
	}
	
	//---------------------------------------------------------
	//Generate Queues (one linked, one arrayed)	
	
	public static <T> QueueIdea<T> newLinkedQueue() {
		Queue<T> struc = new Queue<>();
		struc.setLinked();
		return struc;		
	}
	
	public static <T> QueueIdea<T> newArrayedQueue() {
		Queue<T> struc = new Queue<>();
		struc.setArrayed();
		return struc;
	}
	
	//---------------------------------------------------------
	//Generate Deques (one linked, one arrayed)	
	
	public static <T> DequeIdea<T> newLinkedDeque() {
		Deque<T> struc = new Deque<>();
		struc.setLinked();
		return struc;
	}
	
	public static <T> DequeIdea<T> newArrayedDeque() {
		Deque<T> struc = new Deque<>();
		struc.setArrayed();
		return struc;
	}
	
	//---------------------------------------------------------
	//Generate Bags (one linked, one arrayed)	
	
	public static <T> BagIdea<T> newLinkedBag() {
		Bag<T> struc = new Bag<>();
		struc.setLinked();
		return struc;
	}
	
	public static <T> BagIdea<T> newArrayedBag() {
		Bag<T> struc = new Bag<>();
		struc.setArrayed();
		return struc;
	}	
		
}
