
echo compiling...
echo please wait

javac -cp "src" src/dynarray/*.java
javac -cp "src" src/linkedlist/*.java
javac -cp "src" src/pub/*.java
javac -cp "src" src/ss/*.java

javac -cp "src:test:scorerbase.jar" test/testutil/*.java
javac -cp "src:test:scorerbase.jar" test/tests_cases/*.java

read -p "Press enter to continue"
