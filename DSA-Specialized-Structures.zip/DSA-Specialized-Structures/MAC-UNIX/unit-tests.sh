
java -cp "src:test:scorerbase.jar:ss_support.jar" tests_cases._UnitTestLauncher

read -p "Press enter to continue"
