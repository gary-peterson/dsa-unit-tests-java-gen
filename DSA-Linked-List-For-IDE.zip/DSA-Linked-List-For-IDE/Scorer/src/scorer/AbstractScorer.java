package scorer;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class AbstractScorer<TestSpecType extends TestSpec>
	extends MyObject implements TestCase {

	protected ClassScorerInterface scorer;
	private TestSpecType spec;
	private Log log;
	private String scorableError;
	private int useBestCount;		//e.g. if 7, means use highest problem scores 
									//discard others
	private List<String> tests;
	
	@SuppressWarnings("unused")
	private boolean scoring;	

	// ============================================
	// Constructors

	public AbstractScorer(TestSpecType spec) {
		this.spec = spec;
		this.useBestCount = 0;
		this.scoring = true;
	}

	// ============================================
	// Core
	
	public void setScoring(boolean aScoring) {
		this.scoring = aScoring;
		this.getScorer().setScoring(aScoring);
	}

	public void setMaxScore(int aMaxScore) {
		this.spec.setMaxScore(aMaxScore);
	}

	protected ClassScorerInterface scorerBlt() { 
		ClassScorer scorer = new ClassScorer(this.spec.getLabel());
		scorer.setTestCaseName(this.getClass().getSimpleName());
		scorer.setTestMethodsFrom(this.getTestsAsArray());
		scorer.setAllMaxScores(defaultTestScore());

		int maxFailures = this.defaultMaxErrors();
		if (maxFailures > 0) 
			for (MethodTest mt: scorer.getMethodTests())
				mt.setMaxFailures(maxFailures);
		
		List<SimpleEntry<String, Integer>> specialScores = new ArrayList<>();
		gatherSpecialTestScores(specialScores);
		for (SimpleEntry<String, Integer> assoc : specialScores)
			try {scorer.atTestSetMax(assoc.getKey(), assoc.getValue());}
			catch(Exception ex) {
				//Recursion
				//this.getLog().logException(
				//		"COULD NOT FIND TEST + " assoc.getKey(), ex);
				System.out.println("COULD NOT FIND TEST -- " + assoc.getKey());
			}
		return scorer;
	}

	public void run() {
		if (isScorable()) {
			ClassScorerInterface scorer = getScorer();
			int max = this.useBestCount;			
			scorer.run(this);
			if (max > 0 && max < scorer.testCount()) {  
				scorer.filterToBest(max);
				//rerun with filter on to clear logging related to unused
				scorer.resetLogs();
				scorer.run(this);
			}
		}
		else {
			Exception ex = new Exception(this.getScorableError());
			getScorer().logException("Object Construction", ex);
		}
	}

	// ============================================
	// Testing Setup

	protected abstract String[] getTestNames();

	protected int defaultTestScore() {
		// virtual optional
		int count = this.getTests().size();
		if (count == 0)
			return 0;
		return (int) Math.round(100.0 / count);
	}
	
	protected int defaultMaxErrors() {
		//-1 means no max
		//virtual optional
		return -1;
	}	

	@SuppressWarnings("unused")
	protected void gatherSpecialTestScores(List<SimpleEntry<String, Integer>> list) {
		// Virtual optional
	}
	
	protected boolean hasExplicitTesteeClass() {
		/*If we have a specific testee class return true. If not (e.g. say 
		we get class indirectly via an object obtained from a factory, 
		then return false)*/		
		
		//virtual optional
		return true;
	}

	// ============================================
	// Services
	
	public void printHeader() {
		String separator = "****************************************";
		for (int i=0; i<=1; i++) 
			printf("%s%n", separator);
		printf("%s%n%n", this.getLabel());
	}
	
	// ============================================
	// Working with return types
	
	protected String getReturnTypeName(MethodTest mt, String methodNm, Class<?>... methodParamTypes) {
		return mt.getMethodReturnTypeName(testeeClass(), methodNm, methodParamTypes);
	}	
	
	protected String getReturnTypeNameSafely(MethodTest mt, String methodNm, Class<?>... methodParamTypes) {
		String type = getReturnTypeName(mt, methodNm, methodParamTypes);
		if (type != null)
			return type;
		else
			return "Unknown (method not found)";
	}		

	protected boolean hasReturn(MethodTest mt, String methodNm, Class<?>... methodParamTypes) {
		return mt.hasReturn(testeeClass(), methodNm, methodParamTypes);
	}	
	
	protected boolean hasReturnType(MethodTest mt, String methodNm, String expectedType,
									Class<?>... methodParamTypes) {
		String actualType = getReturnTypeName(mt, methodNm, methodParamTypes);
		if (actualType != null)
			return actualType.equals(expectedType);
		else
			return false;
	}	
		
	// ============================================
	// Checking method signatures	
	
	protected boolean checkSignature(MethodTest mt, String methodNm, Class<?>... methodParamTypes) {
		return mt.checkMethodSignature(testeeClass(), methodNm, methodParamTypes);
	}
	
	protected boolean checkAndApplySignature(MethodTest mt, String methodNm, Class<?>...methodParamTypes) {
		return mt.checkAndApplyMethodSignature(testeeClass(), methodNm, methodParamTypes);
	}	
	
	protected Class<?> testeeClass() {
		//virtual optional
		return this.constructTestee().getClass();
	}
	
	// ============================================
	// Determining if we are scorable
	
	public abstract Object constructTestee();
	
	public abstract String getConstructTesteeSnippet();	

	// ============================================
	// Accessors

	public ClassScorerInterface getScorer() {
		if (scorer == null)
			scorer = scorerBlt();
		return scorer;
	}

	public TestSpecType getSpec() {
		return spec;
	}
	
	@Override
	public Log getLog() {
		Log l = this.getScorer().getLog();
		if (l == null) {
			if (log == null)
				log = new Log();
			l = log;
		}
		return l;
	}	
	
	//alias
	protected Log log() { return getLog(); }
	
	@Override
	public String toString() {
		Object testee = this.getScorer().getTestee();
		if (testee != null)
			return testee.toString();
		else
			return this.getClass().getSimpleName();
	}	
	
	public TotalScoreSummary getSummary() {
		TotalScoreSummary summary = new TotalScoreSummary(getScorer().getSummary(), this.spec.getMaxScore());
		summary.setExtraCredit(this.getSpec().isExtraCredit());
		return summary;
	}	
	
	public String getLabel() {
		return this.spec.getLabel();
	}
	
	public String getScorableError() {
		return scorableError;
	}	
	
	public void printSummaryOn(Log strm) {
		if (this.isScorable())
			this.getScorer().printSummaryOn(strm);
	}
	
	public boolean hasLogContent() {
		return this.isScorable() && this.getScorer().hasLogContent();
	}
	
	public void printLogOn(Log strm) {
		if (this.isScorable())
			this.getScorer().printLogOn(strm);
		else
			this.getScorer().printExceptionsOn(strm);
	}	
	
	public void printOn(Log strm) {
		if (this.isScorable())
			this.getScorer().printOn(strm);
		else
			this.getScorer().printExceptionsOn(strm);
	}
	
	public void printExceptionsOn(Log strm) {
		this.getScorer().printExceptionsOn(strm);
	}	
	
	// ============================================
	// Deriving isScorable	
	
	protected boolean isScorable() {
		if (scorableError == null)
			scorableError = scorabilityDerived();
		return this.scorableError.isEmpty();
	}

	protected String scorabilityDerived() {
		if (hasExplicitTesteeClass() && !isTesteeClassAvailable())
			return String.format("Could not find class (missing or compile errors): %s", this.spec.getTesteeClassName());
		if (!isConstructable())
			return String.format("\tCRITICAL ERROR%n\tSubject not runnable%n\tCould not construct object using this code: %n\t\t%s", 
					getConstructTesteeSnippet());
		return "";
	}
	
	public boolean isConstructable() {
		try { constructTestee(); }
		catch (Exception | Error ex) { 
			return false; }
		return true;
	}
	
	public boolean isTesteeClassAvailable() {
		try { testeeClass(); }
		catch (Exception | Error ex) { 
			return false; }
		return true;
	}	
	
	public void setUseBestCount(int useBestCount) {
		this.useBestCount = useBestCount;
	}	
	
	//todo -- change "getTestNames" to "buildTestNames"
	public List<String> getTests() {
		if (this.tests == null)
			this.tests = Arrays.asList(this.getTestNames());
		return this.tests;
	}
	
	public String[] getTestsAsArray() {
		return this.getTests().toArray(String[]::new);
	}

	public void setTests(List<String> tests) {
		this.tests = tests;
	}	
	
	public void setTests(String[] tests) {
		this.setTests(Arrays.asList(tests));
	}	
	
	// ============================================
	// Helpers
	
	protected boolean isToStringNonDefaultFor(Object o) {
		//Return true if toString is non-default
		String s = o.toString();
		if (s.isEmpty())
			return false;
		String testeeClassName = getSpec().getTesteeClassName();
		if (!s.startsWith(testeeClassName + "@"))
			return true;
		return s.length() != (testeeClassName + "@12345678").length();
	}

	public boolean isPassing() {
		return scorer.isPassing();
	}

	protected String currentTestLabel() {
		if (this.scorer != null)
			return this.scorer.currentTestLabel();
		//return "Nope--AbstractScorer>>currentTestLabel";
		return "";
	}

}
