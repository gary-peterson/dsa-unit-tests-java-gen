package scorer;

public class ScoreSummary {
	
	String label;
	private int score;
	private int possibleScore;
	private boolean extraCredit;

	public ScoreSummary(String label, int score, int possibleScore) {
		super();
		this.label = label;
		this.score = score;
		this.possibleScore = possibleScore;
		this.extraCredit = false;
	}
	
	public ScoreSummary(String label) {
		this(label, 0, 0);
	}
	
	public ScoreSummary(ScoreSummary other) {
		//Copy Constructor
		this(other.getLabel(), other.getScore(), other.getPossibleScore());
	}	
	
	//--------------------------------------------------
	//Services
	
	public void increaseBy(ScoreSummary other) {
		this.score += other.getScore();
		this.possibleScore += other.getPossibleScore();
	}
	
	public String toString() {
		return toStringLabeled("Checks");
	}
	
	public String toStringLabeled(String label) {
		return String.format("%s: %d of %d (%d%%) -- %s",
				label, this.score, this.possibleScore, 
				this.getScorePercent(), this.label); 
	}	
	
	public String toScoringString() {
		//Scoring: 80 of 100
		return String.format("%s: %d of %d", label, this.score, this.possibleScore); 
	}
	
	public String toPercentString() {
		return toPercentString("Percent");
 
	}	
	
	public String toPercentString(String label) {
		//Percent: 80%
		return String.format("%s: %d%%", label, getScorePercent());  
	}		
	
	//--------------------------------------------------
	//Accessors	
	
	public int getScorePercent() {
		int points, max, percentPassing;
		points = this.score;
		max = this.possibleScore;
		percentPassing = (max > 0) 
				? (int) Math.round((points * 100.0) / max) 
				: 0;		
		return percentPassing;
	}
		
	public int getScore() {
		return score;
	}

	public int getPossibleScore() {
		return possibleScore;
	}
	
	public String getLabel() {
		return label;
	}
	
	public boolean isExtraCredit() {
		return extraCredit;
	}

	public void setExtraCredit(boolean extraCredit) {
		this.extraCredit = extraCredit;
	}	
	
}
