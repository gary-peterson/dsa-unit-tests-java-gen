package scorer;

public interface TestCase {
	
	default void beforeEach() {}

}
