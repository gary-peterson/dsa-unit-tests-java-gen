package scorer;
import static scorer.Tools.list;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

class MetaLab {
	
	//-----------------------------------	

	public static void main(String[] args) throws Exception {
		labGetMethodsFromClass();
		labBuildInstanceFromClass();
		runMethodViaReflection();
	}
	
	//-----------------------------------	
	
	public static void labGetMethodsFromClass() {
		List<Method> all, tests, sorted;

		all = Arrays.asList(MetaLab.class.getDeclaredMethods());
		tests = Tools.filter(all, m -> m.getName().startsWith("test"));
		prn(tests);
		
		sorted = list(tests.stream().sorted((a, b) -> a.getName().compareTo(b.getName())));
		prn(sorted);
	}
	
	private static void labBuildInstanceFromClass() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class<?> cl = MetaLabDog.class;
		Constructor<?> constructor = cl.getConstructor(String.class, int.class);
		AbstractDog dog = (AbstractDog)constructor.newInstance("Fido", 153);
		prn(dog);
	}
	
	private static void runMethodViaReflection() throws Exception {
		String methodName, result;
		Method m;
		MetaLabDog dog;
		
		dog = new MetaLabDog("Fido",  100);
		methodName = "getName";
		m = ClassTool.findMethod(methodName, dog.getClass()); 
		result = (String)m.invoke(dog);		
		prn("runMethodFromName -- result: " + result);
	}		
	

	
	//-----------------------------------

	public void testZ() {
		prn("Running testZ");
		prn("Done testZ");		
	}
	
	public void test1() {
		prn("Running test1");
		prn("Done test1");
	}	

	//----------------------------------------
	//Helpers	
	
	public static void prn(Object o) {
		System.out.println(o.toString());
	}

}

//----------------------------------------
//----------------------------------------

class AbstractDog {
}

class MetaLabDog extends AbstractDog {
	private String name;
	private int weight;
	public MetaLabDog(String nm, int wt) {
		this.name = nm;
		this.weight = wt;
	}
	@Override
	public String toString() {
		return this.name + " " + this.weight;
	}
	public String getName() {
		return name;
	}
}
