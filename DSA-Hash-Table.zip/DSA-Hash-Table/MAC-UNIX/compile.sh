
echo compiling...
echo please wait

javac -cp "src:support.jar" src/hashpub/*.java
javac -cp "src:support.jar" src/hash/*.java

javac -cp "src:test:scorerbase.jar:support.jar" test/testutil/*.java
javac -cp "src:test:scorerbase.jar:support.jar" test/tests_cases/*.java

read -p "Press enter to continue"
