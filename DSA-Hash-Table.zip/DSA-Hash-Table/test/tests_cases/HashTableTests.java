/**
    StackTests.java
    3/31/21
*/
package tests_cases;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

import hashpub.HashTableFactory;
import hashpub.HashTableIdea;
import scorer.AbstractScorer;
import scorer.MethodTest;
import scorer.TestSpec;
import testutil.Thing;

/**
 * prim data <Integer, Integer> 
 */
public class HashTableTests extends AbstractScorer<TestSpec> {
	
	private HashTableIdea<Integer, Thing> unit;
	
	// ============================================
	// Constructors

	public HashTableTests(int maxPoints) {
		super(maxPoints, "Hash Table Tests");		
	}	
	
	// =====================================================
	
	protected HashTableIdea<Integer, Thing> unit() {
		return this.unit;
	}	
	
	// ============================================
	// Housekeeping / Test Admin
	
	protected String[] getTestNames() {
		List<String> result = new ArrayList<>();
		String[] localTestNames =
				new String[] {
					"test_construction",
					"test_put_size",
					"test_put_containsKey",
					"test_put_get",
					"test_getIfAbsentPut_get",
					"test_put_keys",
					"test_put_removeKey_size_containsKey",
					"test_put_removeKey_exception",
					"test_put_removeKeyIfAbsent_size_containsKey",
					"test_methodSignatures"
				};
		result.addAll(Arrays.asList(localTestNames));
		return result.toArray(String[]::new);
	}
	
	@Override
	protected void gatherSpecialTestScores(List<SimpleEntry<String, Integer>> list) {
		super.gatherSpecialTestScores(list);
		//list.add(newKV("test_specific_methodSignatures", 10));		
	}	
	
	@Override	
	public String getConstructTesteeSnippet() {
		return "HashTableFactory.newHashTable()";
	}	
	
	@Override
	public Object constructTestee() {
		return HashTableFactory.newHashTable();
	}
		
	// =====================================================
	// Setup

	@Override
	public void beforeEach() {
		this.unit = HashTableFactory.newHashTable();		
	}

	// =====================================================
	// Tests
	
	public void test_construction(MethodTest mt) {
		mt.assertEquals(this.unit() != null, true);
	}
	
	public void test_put_size(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		mt.assertEquals(0, u.size());
		int load = 3;
		for (int i = 1; i <= load; i++) {
			Thing newElem = new Thing(i);
			u.put(i, newElem);
			mt.assertEquals(i, u.size());			
		}
	}
	
	public void test_put_containsKey(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		mt.assertFalse(u.containsKey(1));		
		for (int i = 1; i <= load; i++) {
			Thing newElem = new Thing(i);
			u.put(i, newElem);
			mt.assertTrue(u.containsKey(newElem.getId()));			
		}
	}	
	
	public void test_put_get(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		mt.assertFalse(u.containsKey(1));		
		for (int i = 1; i <= load; i++) {
			Thing newElem = new Thing(i), actual;
			u.put(i, newElem);
			actual = u.get(i);
			mt.assertEquals(newElem, actual);			
		}
	}	
	
	public void test_getIfAbsentPut_get(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		mt.assertFalse(u.containsKey(1));		
		for (int i = 1; i <= load; i++) {
			Thing
				actual = u.getIfAbsentPut(i, key -> new Thing(key)),
				expected = new Thing(i);
			mt.assertEquals(expected, actual);			
			mt.assertEquals(expected, u.get(i));			
		}
	}	
	
	public void test_put_keys(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		List<Integer> expectedKeys = new ArrayList<>();
		for (int i = 1; i <= load; i++) {
			u.put(i, new Thing(i));
			expectedKeys.add(i);
		}
		//order is not specified
		List<Integer> actualKeys = u.keys().toJavaList();
		mt.assertTrue(expectedKeys.containsAll(actualKeys));
		mt.assertEquals(expectedKeys.size(), actualKeys.size());		
	}	
		
	public void test_put_removeKey_size_containsKey(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		for (int i = 1; i <= load; i++)
			u.put(i, new Thing(i));
		for (int i = 1; i <= load; i++) {
			mt.assertEquals(load - i + 1, u.size());
			mt.assertTrue(u.containsKey(i));			
			u.removeKey(i);
			mt.assertEquals(load - i, u.size());
			mt.assertFalse(u.containsKey(i));
		}
	}		
		
	public void test_put_removeKey_exception(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		for (int i = 1; i <= load; i++)
			u.put(i, new Thing(i));
		for (int i = 1; i <= load; i++) {
			final int badKey = i + 100;
			mt.assertExceptionIn(() -> u.removeKey(badKey),
					() -> String.format("expecting exception (true) for bad key %d", badKey));
		}
	}
	
	public void test_put_removeKeyIfAbsent_size_containsKey(MethodTest mt) {
		HashTableIdea<Integer, Thing> u = this.unit();		
		int load = 3;
		for (int i = 1; i <= load; i++)
			u.put(i, new Thing(i));
		for (int i = 1; i <= load; i++) {
			mt.assertEquals(load - i + 1, u.size());
			mt.assertTrue(u.containsKey(i));			
			u.removeKeyIfAbsent(i, () -> null);
			u.removeKeyIfAbsent(i + 100, () -> null);			
			mt.assertEquals(load - i, u.size());
			mt.assertFalse(u.containsKey(i));
		}
	}	

	
	
	
	
	/**
	 * This checks that each expected method (signature) exists
	 * with proper method parameters 
	 */
	public void test_methodSignatures(MethodTest mt) {
		if (checkSignature(mt, "put", Object.class, Object.class))
			mt.record(true, true);
		if (checkSignature(mt, "size"))
			mt.record(true, true);
		if (checkSignature(mt, "containsKey", Object.class))
			mt.record(true, true);		
		if (checkSignature(mt, "get", Object.class))
			mt.record(true, true);
		if (checkSignature(mt, "getIfAbsentPut", Object.class, Function.class))
			mt.record(true, true);		
		if (checkSignature(mt, "keys"))
			mt.record(true, true);		
		if (checkSignature(mt, "removeKey", Object.class))
			mt.record(true, true);		
		if (checkSignature(mt, "removeKeyIfAbsent", Object.class, Supplier.class))
			mt.record(true, true);	
		if (checkSignature(mt, "length"))
			mt.record(true, true);		
	}	

	//----------------------------------------------------
	//Main entry point

	public static void main(String[] args) {
		//TODO
		_UnitTestManager.main(args);
	}

}















