package hashpub;

/**
Interface: DictionaryIdea

The idea for a dictionary (dict).

Overview

	A dictionary operates like a traditional word dictionary.
	What we call "key" is like "word" in a traditional word dictionary.
	We use "get" to look up a value at the *key*. 
	We use "put" to put a *value* into the dict (at a given *key*).
	
	We might also think of the dictionary as a collection of "pairs"
	or "associations" where a "key" is associated with a "value".
	
Data Types

	Both "key" and "value" are generic.
	Thus, types are flexible and up to the dict user.
	Examples:
	
		A dict of Employees keyed by id (an Integer/Long)
		A dict of Cars keyed by vin numbers (a String) 
		
Note: the terms "elem" and "data" are used interchangeably
*/

import java.util.function.Function;
import java.util.function.Supplier;

import pub.DynamicList;

public interface DictionaryIdea<K, V> {

	//--------------------- Adding ---------------------

	/**
	 * If param "key" is already present
	 * 	Then put replace current value at "key" with param "value"
	 * 	Else add new association
	 * Return previous value at key (or null if none)
	 */
	public V put(K key, V value);

	//--------------------- Queries ---------------------

	/**
	 * Return the number of elements in the dictionary.
	 */
	public int size();

	/**
	 * Return true if dictionary contains param "key", else false
	 */
	public boolean containsKey(K key);

	/**
	 * Return value at param "key" or null if key not found
	 */
	public V get(K key);

	/**
	 * If key is found, return value at key
	 * Otherwise construct new value using provider (with key as arg)
	 * 	and add value to this dict, and return value
	 * Very practical convenience function, e.g.:
	 * 	color = specDict.getIfAbsentPut(name, name -> new Spec(name));
	 */
	public V getIfAbsentPut(K key, Function<K, V> provider);
	
	/**
	 * Return list containing all keys (order of keys is not specified)
	 */
	public default DynamicList<K> keys() {
		return null;
	}	

	//--------------------- Removing ---------------------

	/**
	 * Remove key (association) and return previous (removed) value
	 * If key is not found throw RuntimeException
	 */
	public V removeKey(K key);

	/**
	 * Remove key (association) and return previous (removed) value
	 * If key is not found, then return value obtained from param "supplier"
	 * Useful when use does not want exception thrown:
	 * 		dict.removeKeyIfAbsent(key, () -> null);  
	 */
	public V removeKeyIfAbsent(K key, Supplier<V> supplier);

}
