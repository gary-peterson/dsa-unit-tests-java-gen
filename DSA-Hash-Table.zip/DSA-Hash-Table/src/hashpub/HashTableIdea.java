package hashpub;

/**
 * Interface: HashTableIdea
 * Super-Interface: DictionaryIdea
 * 
 * We get almost all of our ideas from our super-interface
 * 
 */

public interface HashTableIdea<K, V> extends DictionaryIdea<K, V> {
	
	//--------------------- Queries ---------------------	
	
	/**
	 * Return the length of the hash table (i.e. the number of "buckets")
	 * This (bucket count) is specific to a hash table 
	 * NOTE WELL -- this is not the same as "size". 	
	 */
	public int length();	

}
