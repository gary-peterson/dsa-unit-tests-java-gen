
echo compiling...
echo please wait

javac -cp "src:support.jar" src/bstpub/*.java
javac -cp "src:support.jar" src/bst/*.java

javac -cp "src:test:scorerbase.jar:support.jar" test/testutil/*.java
javac -cp "src:test:scorerbase.jar:support.jar" test/tests_cases/*.java

read -p "Press enter to continue"
