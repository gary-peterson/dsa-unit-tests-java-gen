
java -cp "src:test:scorerbase.jar:support.jar" tests_cases._UnitTestManager

read -p "Press enter to continue"
