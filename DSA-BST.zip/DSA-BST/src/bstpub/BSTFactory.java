
/**
 * class: BSTFactory
 * 4/9/21
 * Constructs and returns new 
 * binary search (bst) trees
 * */ 

package bstpub;

import java.util.Comparator;
import java.util.function.BiFunction;

import bst.BST;

public class BSTFactory {
	
	public static <E, K> BSTIdea<E, K> newBST(Comparator<E> sortFct, 
												BiFunction<K, E, Integer> searchFct) {
		//NOTE -- This assumes a tree class name of BST. If your tree class
		//name is different, simply replace "BST" with it.
		return new BST<>(sortFct, searchFct); 
	}	

}
