package tests_cases;

import testutil.Thing;

public class _UnitTestManager {
	
	public static <T> BSTTestSuite<T> newTestSuiteWithScoring() {
		BSTTestSuite<T> suite;
		suite = new BSTTestSuite<>();
		suite.setShouldScore(true);
		return suite;
	}		

	public static <T> BSTTestSuite<T> newTestSuite() {
		BSTTestSuite<T> suite;
		suite = new BSTTestSuite<>();
		return suite;
	}
	
	//----------------------------

	public static void main(String[] args) {
		BSTTestSuite<Thing> suite;
		suite = new BSTTestSuite<>();
		//String[] array = args;
		String[] array = new String[] { "y" };
		boolean shouldScore = array.length > 0 ? array[0].toLowerCase().equals("y") : false;
		suite.runAll(false, shouldScore);
	}

}
