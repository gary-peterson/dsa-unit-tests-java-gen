package tests_cases;

import static testutil.DSTestTool.empNameFrom;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;

import bstpub.BSTFactory;
import bstpub.BSTIdea;
import scorer.AbstractScorer;
import scorer.MethodTest;
import scorer.TestSpec;
import scorer.Tools;
import testutil.DSTestTool;
import testutil.Employee;


public class BSTScorer extends AbstractScorer<TestSpec> {

	// ============================================
	// Constructors

	private BSTScorer(TestSpec aSpec) {
		super(aSpec);
	}

	public BSTScorer(int maxPoints) {
		this(new TestSpec(maxPoints, "BSTIdea"));
	}

	// =====================================================
	// System 	

	@Override
	protected String[] getTestNames() {
		return new String[] {

				"test_construct",
		
				"test_add",
				"test_visitInOrder",
				"test_visitPreOrder",
				"test_visitPostOrder",
				
				"test_height_treeSize0",
				"test_height_treeSize1",				
				"test_height_courseNotesExample2Data",
				
				"test_isEmpty_emptyTree",
				"test_isEmpty_nonEmptyTree",
				
				"test_search_expectingMatch",
				"test_search_expectingNoMatch",
				
				"test_contains_true",
				"test_contains_false",
				
				"test_remove_removalsInRandomOrder",
				"test_remove_removalsInSortedOrder",
				"test_remove_removalsInReverseSortedOrder",
				
				/*"test_toIterator",
				"test_toPreOrderIterator",*/
				
				"test_balance_randomInput",
				"test_balance_preSortedInput",
				"test_balance_preReverseSortedInput",
				
				"test_load"
		};
	}

	protected int defaultTestScore() {
		return 100;
	}

	@Override
	protected void gatherSpecialTestScores(List<SimpleEntry<String, Integer>> list) {
		super.gatherSpecialTestScores(list);
		
				list.add(newKV("test_construct", 67));		
		
				list.add(newKV("test_add", 67));
				list.add(newKV("test_visitInOrder", 67));				
				list.add(newKV("test_visitPreOrder", 67));
				list.add(newKV("test_visitPostOrder", 67));				
				
				list.add(newKV("test_height_treeSize0", 67));
				list.add(newKV("test_height_treeSize1", 67));
				list.add(newKV("test_height_courseNotesExample2Data", 67));
				
				list.add(newKV("test_isEmpty_emptyTree", 67));
				list.add(newKV("test_isEmpty_nonEmptyTree", 67));				
				
				list.add(newKV("test_search_expectingMatch", 67));
				list.add(newKV("test_search_expectingNoMatch", 67));				
				
				list.add(newKV("test_contains_true", 67));
				list.add(newKV("test_contains_false", 67));
				
				list.add(newKV("test_load", 62));				
												
				//4
				list.add(newKV("test_remove_removalsInRandomOrder", 133));
				list.add(newKV("test_remove_removalsInSortedOrder", 133));
				list.add(newKV("test_remove_removalsInReverseSortedOrder", 134));				
				
				//4
				list.add(newKV("test_toIterator", 400));
				
				//3
				list.add(newKV("test_toPreOrderIterator", 300));
				
				//4
				list.add(newKV("test_balance_randomInput", 100));
				list.add(newKV("test_balance_preSortedInput", 100));				
				list.add(newKV("test_balance_preReverseSortedInput", 100));
												
	}

	@Override
	protected Class<?> testeeClass() {
		return this.constructTestee().getClass();
	}

	protected int defaultMaxErrors() {
		return 4;
	}

	// =====================================================
	// Test Constructor and Access

	@Override
	public Object constructTestee() {
		return BSTFactory.newBST(sortFct1(), searchFct1());
	}

	@Override
	public String getConstructTesteeSnippet() {
		return "BSTFactory.newBST(sortFct1(), searchFct1());";
	}
	
	protected List<Integer> example2Data() {
		//From course notes
		//NOTE WELL -- adding (100) here to notes example so we always
		//remain in balace (e.g. eliminate balance as factor for non-balance tests
		//Will test balance separately
		return Arrays.asList(50, 70, 20, 10, 60, 40, 100, 30);
	}
	
	protected List<Integer> example2DataSorted() {
		//From course notes
		List<Integer> list = example2Data();
		Collections.sort(list);
		return list;
	}	
	
	protected List<Integer> example2DataReverseSorted() {
		//From course notes
		List<Integer> list = example2DataSorted();
		Collections.reverse(list);
		return list;
	}	
	
	protected List<Integer> example2DataRandomized() {
		//From course notes
		List<Integer> list = example2Data();
		Collections.shuffle(list);
		return list;
	}	
	
	protected List<String> example2NamesInOrder() {
		return Tools.collect(this.example2DataSorted(), id -> empNameFrom(id));
	}	
	
	//--------------------------------------------------------
	
	protected static BSTIdea<Employee, Integer> newTreeFrom(List<Employee> list) {
		BSTIdea<Employee, Integer> bst;
		bst = BSTFactory.newBST(sortFct1(), searchFct1());		
		for (Employee eaEmp: list)
			bst.add(eaEmp);
		Employee employee1=null, employee2=null;
		bst
			.add(employee1)
			.add(employee2);
		return bst;
	}	

	protected static BSTIdea<Employee, Integer> newTreeFromIds(List<Integer> ids) {
		BSTIdea<Employee, Integer> bst;
		bst = BSTFactory.newBST(sortFct1(), searchFct1());		
		for (Integer id: ids)
			bst.add(new Employee(id, empNameFrom(id)));	
		return bst;
	}	
		
	//--------------------------------------------------------	
	
	protected BSTIdea<Employee, Integer> example2Tree() {
		//From course notes
		//keys are from example #2, names are: "Name-${key}"
		BSTIdea<Employee, Integer> bst;
		bst = BSTFactory.newBST(sortFct1(), searchFct1());		
		for (int eaId: example2Data())
			bst.add(new Employee(eaId, empNameFrom(eaId)));	
		return bst;
	}
	
	protected BSTIdea<Employee, Integer> newEmptyTree() {
		return BSTFactory.newBST(sortFct1(), searchFct1());		
	}	
	
	protected BSTIdea<Employee, Integer> newTreeOfSizeOne() {
		BSTIdea<Employee, Integer> bst;
		bst = BSTFactory.newBST(sortFct1(), searchFct1());
		bst.add(new Employee(100, empNameFrom(100)));
		return bst;		
	}	
		
	protected String example2DataString() {
		//From course notes
		return example2Data().toString();
	}	
		
	protected String example2DataMsg() {
		//From course notes
		return "tree with input: " + example2DataString();
	}
	
	private static Integer wrap(int x)  {
		return x;
	}	
	
	protected static Comparator<Employee> sortFct1() {
		return (emp1, emp2) -> searchFct1().apply(emp1.getId(), emp2); 
	}
	
	protected static BiFunction<Integer, Employee, Integer> searchFct1() {
		return (id, emp) -> wrap(id).compareTo(emp.getId());
	}	
	
	
	// =====================================================
	// Test core methods
	
	public void test_construct(MethodTest mt) {
//		if (!checkSignature(mt, "BST", Comparator.class, BiFunction.class))
//			return;
		newEmptyTree();
		//If we make it this far (no exception occurred) we pass
		mt.record(true, true, "(pre check) Constructability check");
	}	
	
	public void test_load(MethodTest mt) {
//		if (!checkSignature(mt, "BST", Comparator.class, BiFunction.class))
//			return;
		newTreeFromIds(DSTestTool.randomIds(10000));
		//If we make it this far (no exception occurred) we pass
		mt.record(true, true, "Testing larger load (no exceptions)");
	}	
	
	public void test_add(MethodTest mt) {
		if (!checkSignature(mt, "add", Object.class))
			return;
		BSTIdea<Employee, Integer> bst;
		bst = newEmptyTree();
		bst.add(new Employee(1, "Kofi Kingston"));
		//If we make it this far (no exception occurred) we pass
		mt.record(true, true, "(pre check) Run check - checking that add runs w/o exception");
	}	

	public void test_visitInOrder(MethodTest mt) {
		if (!checkSignature(mt, "visitInOrder", Consumer.class))
			return;
		
		List<Integer> 
			visitedData = new ArrayList<>(),
			expected = Arrays.asList(10, 20, 30, 40, 50, 60, 70, 100);		
		
		BSTIdea<Employee, Integer> bst;
		bst = example2Tree();		
		bst.visitInOrder(emp -> visitedData.add(emp.getId()));

		mt.record(visitedData, expected, example2DataMsg());
	}
	
	public void test_visitPreOrder(MethodTest mt) {
		if (!checkSignature(mt, "visitPreOrder", Consumer.class))
			return;
		
		List<Integer> 
			visitedData = new ArrayList<>(),
			expected = Arrays.asList(50, 20, 10, 40, 30, 70, 60, 100);		
		
		BSTIdea<Employee, Integer> bst;
		bst = example2Tree();		
		bst.visitPreOrder(emp -> visitedData.add(emp.getId()));

		mt.record(visitedData, expected, example2DataMsg());
	}	
	
	public void test_visitPostOrder(MethodTest mt) {
		if (!checkSignature(mt, "visitPostOrder", Consumer.class))
			return;
		
		List<Integer> 
			visitedData = new ArrayList<>(),
			expected = Arrays.asList(10, 30, 40, 20, 60, 100, 70, 50);		
		
		BSTIdea<Employee, Integer> bst;
		bst = example2Tree();		
		bst.visitPostOrder(emp -> visitedData.add(emp.getId()));

		mt.record(visitedData, expected, example2DataMsg());
	}	
		
	//----------------------------------------------------	
	// Test non-core methods - height
	
	public void test_height_treeSize0(MethodTest mt) {
		if (!checkSignature(mt, "height"))
			return;
		mt.record(this.newEmptyTree().height(), 0, "height check on empty tree");
	}
		
	public void test_height_treeSize1(MethodTest mt) {
		if (!checkSignature(mt, "height"))
			return;
		int h = this.newTreeOfSizeOne().height();		
		boolean okay = DSTestTool.between(h, 0, 1);
		String template = "height check on tree of size 1 -- actual height = %d";
		mt.record(okay, String.format(template, h));		
	}
	
	public void test_height_courseNotesExample2Data(MethodTest mt) {
		if (!checkSignature(mt, "height"))
			return;
		int h = this.example2Tree().height();		
		boolean okay = DSTestTool.between(h, 3, 4);
		String template = "height check on tree with input: %s -- actual height = %d";
		mt.record(okay, String.format(template, example2DataString(), h));		
	}	
	
	//----------------------------------------------------	
	// Test non-core methods - isEmpty
	
	public void test_isEmpty_emptyTree(MethodTest mt) {
		if (!checkSignature(mt, "isEmpty"))
			return;
		mt.record(this.newEmptyTree().isEmpty(), true, "isEmpty check on empty tree");
	}
		
	public void test_isEmpty_nonEmptyTree(MethodTest mt) {
		if (!checkSignature(mt, "height"))
			return;
		mt.record(this.example2Tree().isEmpty(), false, "isEmpty check on non-empty tree");
	}
	
	//----------------------------------------------------	
	// Test non-core methods - search
	
	public void test_search_expectingMatch(MethodTest mt) {
		if (!checkSignature(mt, "search", Object.class))
			return;
		BSTIdea<Employee, Integer> bst;			
		bst = this.example2Tree();
		List<Integer> inputList = example2Data();		
		String msg = example2DataMsg();
		for (Integer key: inputList)
			mt.record(bst.search(key), new Employee(key, empNameFrom(key)), msg);
		mt.setMaxFailures(2);
		mt.setFailuresThreshold(2);		
	}
		
	public void test_search_expectingNoMatch(MethodTest mt) {
		if (!checkSignature(mt, "search", Object.class))
			return;
		BSTIdea<Employee, Integer> bst;			
		bst = this.example2Tree();
		List<Integer> inputList = example2Data();		
		String msg = example2DataMsg();
		for (Integer key: inputList)
			mt.record(bst.search(key+1000), null, msg);
		mt.setMaxFailures(2);
		mt.setFailuresThreshold(2);		
	}	
	
	//----------------------------------------------------	
	// Test non-core methods - contains
	
	public void test_contains_true(MethodTest mt) {
		if (!checkSignature(mt, "containsKey", Object.class))
			return;
		BSTIdea<Employee, Integer> bst;			
		bst = this.example2Tree();
		List<Integer> inputList = example2Data();		
		String msg = example2DataMsg();
		for (Integer key: inputList)
			mt.record(bst.containsKey(key), true, msg);
		mt.setMaxFailures(2);
		mt.setFailuresThreshold(2);		
	}
		
	public void test_contains_false(MethodTest mt) {
		if (!checkSignature(mt, "containsKey", Object.class))
			return;
		BSTIdea<Employee, Integer> bst;			
		bst = this.example2Tree();
		List<Integer> inputList = example2Data();		
		String msg = example2DataMsg();
		for (Integer key: inputList)
			mt.record(bst.containsKey(key+1000), false, msg);
		mt.setMaxFailures(2);
		mt.setFailuresThreshold(2);		
	}
	
	//----------------------------------------------------	
	// Remove
	
	public void test_remove_removalsInRandomOrder(MethodTest mt) {
		basicTestRemove(mt, "removing keys with removals in random order", this.example2DataRandomized()); 	
	}	
	
	public void test_remove_removalsInSortedOrder(MethodTest mt) {
		basicTestRemove(mt, "removing keys with removals in sorted order", this.example2DataSorted());	
	}
	
	public void test_remove_removalsInReverseSortedOrder(MethodTest mt) {
		basicTestRemove(mt, "removing keys with removals in reverse sorted order", example2DataReverseSorted());	
	}

	protected void basicTestRemove(MethodTest mt, String msgPrefix, List<Integer> removals) {
		if (!checkSignature(mt, "removeKey", Object.class))
			return;
		BSTIdea<Employee, Integer> bst = this.example2Tree();
		basicTestRemove(mt, msgPrefix, bst, removals, example2DataSorted());
  		mt.setMaxFailures(4);
		mt.setFailuresThreshold(4);	
	}	
		
	protected void basicTestRemove(MethodTest mt,
									String msgPrefix,
									BSTIdea<Employee, Integer> bst, 
									List<Integer> removals,
									List<Integer> aSorted) {
		List<Integer> sorted = new ArrayList<>(aSorted);
		for (Integer key: removals) {
			bst.removeKey(key);
			sorted.remove(key);
			List<Integer> visitedData = new ArrayList<Integer>();
			bst.visitInOrder(emp -> visitedData.add(emp.getId()));
			mt.record(visitedData, sorted, msgPrefix + " - removed " + key);
		}
	}

	//----------------------------------------------------	
	// Iterators
	
	public void test_toIterator(MethodTest mt) {
		if (!checkSignature(mt, "visitInOrder", Consumer.class))
			return;
		
		BSTIdea<Employee, Integer> bst = this.example2Tree();
		
		Iterator<Employee> iter = bst.toIterator();
			
		List<String>
			expected = example2NamesInOrder(),
			iteratedData = new ArrayList<>();
		
		while (iter.hasNext())
			iteratedData.add(iter.next().getName());
		
		mt.record(iteratedData, expected, "in order iteration");
	}
	
	public void test_toPreOrderIterator (MethodTest mt) {
		if (!checkSignature(mt, "visitInOrder", Consumer.class))
			return;
		
		BSTIdea<Employee, Integer> bst = this.example2Tree();
		
		Iterator<Employee> iter = bst.toPreOrderIterator();
			
		List<Integer> expectedIds = Arrays.asList(50, 20, 10, 40, 30, 70, 60, 100);		
		List<String>
			expected = Tools.collect(expectedIds, id -> empNameFrom(id)),
			iteratedData = new ArrayList<>();
		
		while (iter.hasNext())
			iteratedData.add(iter.next().getName());
		
		mt.record(iteratedData, expected, "pre order iteration");
	}	
	
	//----------------------------------------------------	
	// Balance
	
	public void test_balance_randomInput(MethodTest mt) {
	
		BSTIdea<Employee, Integer> bst = newTreeFromIds(DSTestTool.randomIds(1000));
		
		int expectedHeight, height;
		boolean okay;
		String msg;
		
		//1000 log: 2
		expectedHeight = 10;
		height = bst.height();
		
		okay = Math.abs(expectedHeight - height) <= 2;
		
		msg = String.format("1000 elements (%s input), expecting tree height of %d +/- 2 (actual %d)",
				"random", expectedHeight, height);
		mt.record(okay, msg);		
	}	
	
	public void test_balance_preSortedInput(MethodTest mt) {
		
		BSTIdea<Employee, Integer> bst = newTreeFromIds(DSTestTool.sortedIds(1000));
		
		int expectedHeight, height;
		boolean okay;
		String msg;		
		
		//1000 log: 2
		expectedHeight = 10;
		height = bst.height();
		
		okay = Math.abs(expectedHeight - height) <= 2; 
		
		msg = String.format("1000 elements (%s input), expecting tree height of %d +/- 2 (actual %d)",
				"pre-sorted", expectedHeight, height);
		mt.record(okay, msg);			
				
	}		
	
	public void test_balance_preReverseSortedInput(MethodTest mt) {
		
		BSTIdea<Employee, Integer> bst = newTreeFromIds(DSTestTool.reverseSortedIds(1000));
		
		int expectedHeight, height;
		boolean okay;
		String msg;
				
		//1000 log: 2
		expectedHeight = 10;
		height = bst.height();
		
		okay = Math.abs(expectedHeight - height) <= 2; 
		
		msg = String.format("1000 elements (%s input), expecting tree height of %d +/- 2 (actual %d)",
				"pre-sorted", expectedHeight, height);
		mt.record(okay, msg);		
	}	
		
	//----------------------------------------------------
	//Main

	public static void main(String[] args) {
		_UnitTestManager.main(args);
	}

}
