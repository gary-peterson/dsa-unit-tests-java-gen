package testutil;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import scorer.Tools;

public class DSTestTool {
	
	static public List<Integer> randomIds(int count) {
		List<Integer> list;
		list = 
			IntStream.range(1, count+1).boxed()
				.collect(Collectors.toList());
		Collections.shuffle(list);
		return list;
	}
	
	static public List<Integer> sortedIds(int count) {
		List<Integer> list;
		list = 
			IntStream.range(1, count+1).boxed()
				.collect(Collectors.toList());
		Collections.sort(list);
		return list;
	}
	
	static public List<Integer> reverseSortedIds(int count) {
		List<Integer> list = sortedIds(count);
		Collections.reverse(list);
		return list;
	}		
	
	
	//---------------------------------------------------
	//Employees (emps)
	
	static public String empNameFrom(int id) {
		return "Name-" + id;
	}
		
	static public List<Employee> empsFromIds(List<Integer> ids) {
		return Tools.collect(ids, id -> new Employee(id,  empNameFrom(id)));
	}		
	
	static public boolean between(int a, int start, int stop) {
		return a >= start && a <= stop;
	}

}
