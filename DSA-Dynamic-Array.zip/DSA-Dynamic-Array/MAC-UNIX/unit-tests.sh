
java -cp "src:test:scorerbase.jar" tests_cases._UnitTestLauncher

read -p "Press enter to continue"
