package mock;

import java.util.Hashtable;
import java.util.Map;

public class SimpleMock {
	
	Map<String, Object> props;

	public SimpleMock() {
		super();
		this.props = new Hashtable<>();
	}
	
	public Object getProperty(String key) {
		return props.get(key);
	}
	
	public Object putProperty(String key, Object value) {
		return props.put(key, value);
	}	
	
	public int propAsInteger(String key) {
		return Integer.valueOf(propAsString(key));
	}	
	
	public String propAsString(String key) {
		return getProperty(key).toString();
	}	
	
	public boolean propAsBoolean(String key) {
		return Boolean.valueOf(propAsString(key));
	}	

}
