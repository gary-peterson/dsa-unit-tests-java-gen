package unit_test.unit_test_ui;

import java.awt.Component;
import java.awt.Container;
//import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JComponent;
import javax.swing.Timer;

public class Controller {

	Container view;
	Timer timer;

	//===========================================================================	

	public Controller(Container view) {
		super();
		this.view = view;
		this.timer = null;
	}

	//---------------------------------------------------	

	protected JComponent elem(String elemName) {
		return elemRecursively(elemName);
	}

	protected JComponent elemRecursively(String nm, Component[] components) {
		for (Component ea : components)
			if (ea.getName() != null && ea.getName().equals(nm))
				return (JComponent) ea;
			else if (ea instanceof Container) {
				JComponent found = elemRecursively(nm, ((Container) ea).getComponents());
				if (found != null)
					return found;
			}
		return null;
	}

	protected JComponent elemRecursively(String nm) {
		return elemRecursively(nm, this.view.getComponents());
	}

	//---------------------------------------------------

	//----------------------------------------------------
	//Timer for Status
	
	protected void startTimer(int period) {
		stopTimer();
		this.timer = new Timer(period, event -> timerTicked());
		this.timer.setInitialDelay(50);
		this.timer.setDelay(period);
		this.timer.setRepeats(true);
		this.timer.start();
	}	

	protected void stopTimer() {
		if (this.timer != null) {
			this.timer.stop();
			this.timer = null;
		}
	}

	protected void timerTicked() {
		//virtual optional
	}

	//---------------------------------------------------



}
