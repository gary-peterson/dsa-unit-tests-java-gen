package unit_test.unit_test_ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import unit_test.unit_test_model.UnitTestManagerIdea;

public class UnitTestFieldGenerator {

	//		public static JPanel constructMainPanel(A2UnitTestsView app) {
	//			JPanel groupPane = new JPanel();
	//			app.setLayout(groupPane);
	//			app.add(groupPane);
	//			return groupPane;
	//		}

	public static void constructLog(Container mainPanel) {
		JTextArea textArea = new JTextArea(35, 80);
		//JTextArea textArea = new JTextArea(5, 80);
		textArea.setName("log");
		JScrollPane scrollPane = new JScrollPane(textArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		textArea.setText("");
		textArea.setLineWrap(false);

		Font font = textArea.getFont();
		textArea.setFont(new Font(font.getFontName(), Font.PLAIN, 18));

		//textArea.setFont(new java.awt.Font("Courier New", Font.PLAIN, 18));			
		//textArea.setSize(1000, 80);
		//textArea.setSize(textArea.getPreferredSize());
		//groupPane.add(scrollPane);
		//groupPane.setFont(new java.awt.Font("Courier New", 2, 48));
		//groupPane.setLayout(new BoxLayout(groupPane, BoxLayout.X_AXIS));

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.anchor = GridBagConstraints.PAGE_END;
		mainPanel.add(scrollPane, c);
	}

	@SuppressWarnings("unchecked")
	public static void constructActionsPanel(UnitTestController controller, Container mainPanel) {
		JPanel actionPanel = new JPanel();
		JButton button;

		button = new JButton("Select All Cases");
		button.setName("selectAllCases");
		button.addActionListener(evt -> controller.clickedSelectAll((JList<String>) controller.elem("testCases")));
		actionPanel.add(button);

		button = new JButton("Select All Tests");
		button.setName("selectAllTests");
		button.addActionListener(evt -> controller.clickedSelectAll((JList<String>) controller.elem("tests")));
		actionPanel.add(button);

		button = new JButton("Run");
		button.setName("run");
		button.addActionListener(evt -> controller.clickedRun());
		actionPanel.add(button);

		JLabel status = new JLabel("            ");
		status.setFont(new java.awt.Font("Century Schoolbook L", Font.BOLD, 24));
		status.setName("status");
		//status.setVisible(false);
		status.setOpaque(true); //to allow setting background
		actionPanel.add(status);

		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.WEST;
		c.gridx = 0;
		c.gridy = 0;
		mainPanel.add(actionPanel, c);
	}

	@SuppressWarnings("rawtypes")
	public static void clickedSelectAll(JList list) {
		//JList list = (JList)app.elem("testCases");
		list.setSelectionInterval(0, list.getModel().getSize() - 1);
	}

	//------------------------------------------------------------------------

	public static void constructChoicesPanel(UnitTestController controller, Container mainPanel) {
		JPanel panel = new JPanel(new GridLayout(1, 2, 10, 10));
		buildTestCasesList(controller, panel);
		buildTestsList(controller, panel);
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.WEST;
		c.gridx = 0;
		c.gridy = 1;
		mainPanel.add(panel, c);
	}

	public static void buildTestCasesList(UnitTestController controller, JPanel parentPanel) {
		String[] tests;
		tests = testMgr().testCaseNames().toArray(String[]::new);

		//String[] tests = { "TestCase1", "TestCase2", "TestCase3" }; 
		JList<String> listBox = new JList<>();
		listBox.setName("testCases");
		//listBox.setPreferredSize(new Dimension(300, 110));
		listBox.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		listBox.setVisibleRowCount(6); // to keep all values visible
		listBox.setListData(tests);
		listBox.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				controller.changedTestCases(e);
			}
		});

		JScrollPane scrollPane = new JScrollPane(listBox, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setPreferredSize(new Dimension(300, 110));
		scrollPane.getViewport().add(listBox);
		//parentPanel.add(listBox);
		parentPanel.add(scrollPane);
	}
	
	public static void buildTestsList(UnitTestController controller, JPanel parentPanel) {
		String[] tests = { };
		//String[] tests = { "TestCase1", "TestCase2", "TestCase3", "4", "5", "6", "7", "8", "9", "10" }; 
		JList<String> listBox = new JList<>();
		listBox.setName("tests");
		//XDOC DO NOT DO NEXT LINE (messes up scrolling)
		//listBox.setPreferredSize(new Dimension(300, 110));
		listBox.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		listBox.setVisibleRowCount(6); // to keep all values visible
		listBox.setListData(tests);
		listBox.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				controller.changedTests(e);
			}
		});
		JScrollPane scrollPane = new JScrollPane(listBox, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setPreferredSize(new Dimension(300, 110));
		scrollPane.getViewport().add(listBox);
		//parentPanel.add(listBox);
		parentPanel.add(scrollPane);
	}

	public static void buildTestsListOld(UnitTestController controller, JPanel parentPanel) {
			//String[] tests = { "testWidth", "testHeight", "testArea" };
			String[] tests = new String[20];
			for (int i=0; i<20; i++)
				tests[i] = "" + i;
			JList<String> listBox = new JList<>();
			listBox.setName("tests");
			listBox.setPreferredSize(new Dimension(300, 50));
			listBox.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			listBox.setVisibleRowCount(3); // to keep all values visible
			System.out.println("list count: " + tests.length);
			listBox.setListData(tests);
			//getSelectedIndices
			listBox.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent e) {
					controller.changedTests(e);					
				}
			});
			
			//JScrollPane listScroller = new JScrollPane();
			JScrollPane scrollPane = new JScrollPane(listBox,
					ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
					ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			scrollPane.setPreferredSize(new Dimension(300, 110));			
			scrollPane.setViewportView(listBox);
			//listBox.setLayoutOrientation(JList.VERTICAL);
            parentPanel.add(scrollPane);			

//			JScrollPane scrollPane = new JScrollPane(listBox,
//					ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
//					ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
//			scrollPane.setPreferredSize(new Dimension(300, 50));
//			scrollPane.getViewport().add(listBox);
//			//parentPanel.add(listBox);
//			parentPanel.add(scrollPane);			
			
		}

	public static JTextArea addInput(int width, String name, String label, JPanel container) {
		JTextArea input = new JTextArea(1, width);
		input.setBorder(BorderFactory.createLineBorder(Color.black));
		input.setName(name);
		container.add(new JLabel(label));
		container.add(input);
		return input;
	}

	public static JCheckBox addCheckBox(String name, String label, JPanel container) {
		JCheckBox w = new JCheckBox(label);
		w.setBorder(BorderFactory.createLineBorder(Color.black));
		//w.setFont(new java.awt.Font("Century Schoolbook L", 2, 48));
		w.setName(name);
		container.add(w);
		return w;
	}

	public static JComboBox<String> addCombo(String name, String[] labels, JPanel container) {
		JComboBox<String> combo = new JComboBox<String>(labels);
		combo.setName(name);
		container.add(combo);
		return combo;
	}

	public static void changeFont(Component parent, Font font) {
		parent.setFont(font);
		if (parent instanceof Container)
			for (Component eachChild : ((Container) parent).getComponents())
				changeFont(eachChild, font);
	}

	//-------------------------------------------------------

	protected static UnitTestManagerIdea testMgr() {
		return UnitTestConfiguration.getTestManager();
	}

}
