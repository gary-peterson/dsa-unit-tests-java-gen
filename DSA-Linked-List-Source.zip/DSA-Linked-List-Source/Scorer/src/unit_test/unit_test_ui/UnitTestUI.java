package unit_test.unit_test_ui;

import java.awt.Container;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class UnitTestUI {

	//---------------------------------------------------------
	//Entry Point	
	
	public static void openView() {
	     javax.swing.SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                createAndShowView();
	            }
	        });
	}	
	
	//---------------------------------------------------------

	private static void addComponentsToPane(Container container, UnitTestController controller) {
		
		//panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		container.setLayout(new GridBagLayout());		

		UnitTestFieldGenerator.constructActionsPanel(controller, container);

		//mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));
		UnitTestFieldGenerator.constructChoicesPanel(controller, container);

		//mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));
		UnitTestFieldGenerator.constructLog(container);		
	}	

	//---------------------------------------------------
	
	private static void createAndShowView() {
		JFrame view = new JFrame();
		view.setFont(new java.awt.Font("Century Schoolbook L", 2, 18));
		view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		view.setSize(1000, 1000);
		view.setTitle("Unit Tests");

		Container mainView = view.getContentPane();
		UnitTestController controller = new UnitTestController(mainView);		
		addComponentsToPane(mainView, controller);		
		
		view.pack();
		view.setLocationRelativeTo(null);
		view.setVisible(true);

		view.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent we) {
				controller.windowOpened();
			}
		});
	}
	
//	public static void main(String[] args) {
//		UnitTestUI.openView();
//	}

	//===========================================================================	

	public static void prn(Object o) {
		System.out.println(o.toString());
	}

}
