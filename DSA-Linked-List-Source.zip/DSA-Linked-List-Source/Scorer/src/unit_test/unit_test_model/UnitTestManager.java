package unit_test.unit_test_model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import scorer.AbstractScorer;
import scorer.AssignmentScorer;
import scorer.TestSpec;
import scorer.Tools;

public abstract class UnitTestManager implements UnitTestManagerIdea {
	
	private boolean shouldScore;
	private boolean headfull;		//true if it has ui, otherwise assume report only
	
	public boolean isHeadfull() {
		return headfull;
	}

	public void setHeadfull(boolean headfull) {
		this.headfull = headfull;
	}

	//----------------------------------------------	

	public UnitTestManager(boolean aShouldScore) {
		super();
		this.shouldScore = aShouldScore;
		this.headfull = true;	//ui
	}

	//----------------------------------------------	

	@Override
	public AssignmentScorer run(List<String> testCaseNames, List<String> testsNames) {
		if (testCaseNames.size() == 1 && !testsNames.isEmpty())
			return basicOneRun(testCaseNames.get(0), testsNames);
		else
			return basicRun(testCaseNames);
	}
		
	//----------------------------------------------	
	
	@Override	
	public List<String> testNamesIn(String testCaseName) {
		AbstractScorer<TestSpec> scorer;
		scorer = this.newTestCaseSafely(this.testCaseClassNamed(testCaseName));
		return scorer.getTests();
		/*
		Note that "getDeclaredMethods" does not preserve order (as coded)
		thus the use of "getTests" above
		all = Arrays.asList(this.testCaseClassNamed(testCaseName).getDeclaredMethods());
		tests = Tools.filter(all, m -> m.getName().startsWith("test"));
		return Tools.collect(tests, each -> each.getName());
		*/
	}	
	
	//----------------------------------------------	
	
	
	public abstract AbstractScorer<TestSpec> newTestCase(Class<?> testCase) throws Exception;
	
	public AbstractScorer<TestSpec> newTestCaseSafely(Class<?> testCase) {
		try {
			return newTestCase(testCase);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	//----------------------------------------------
	
	public Class<?> testCaseClassNamed(String nm) {
		if (nm == null) return null;
		for (Class<?> eachClass: this.testCases())
			if (eachClass.getSimpleName().equals(nm))
				return eachClass;
		return null;
	}	
	
	public List<Class<?>> testCaseClassesNamed(List<String> names) {
		return Tools.collect(names, nm -> testCaseClassNamed(nm)); 
	}		
	
	//------------------------------------------
		
	@SuppressWarnings("unchecked")	
	private AssignmentScorer basicRun(List<String> testCaseNames) {
		List<AbstractScorer<TestSpec>> scorers = new ArrayList<>();
		for (Class<?> testCaseClass: testCaseClassesNamed(testCaseNames))
			scorers.add(this.newTestCaseSafely(testCaseClass));
		return basicRunScorers(scorers.toArray(AbstractScorer[]::new));
	}	
	
	private AssignmentScorer basicOneRun(String testClassName, List<String> testNames) {
		AbstractScorer<TestSpec> scorer;
		scorer = this.newTestCaseSafely(this.testCaseClassNamed(testClassName));
		scorer.setTests(testNames);
		return basicRunScorers(scorer);
	}	

	@SafeVarargs
	private final AssignmentScorer basicRunScorers(AbstractScorer<TestSpec> ...scorers) {
		AssignmentScorer aggregateScorer;
		
		int count, aveMaxScore;
		count = scorers.length;
		aveMaxScore = 100 / count;
		for (AbstractScorer<TestSpec> each: scorers)
			each.setMaxScore(aveMaxScore);
		for (int i=0, diff=100-(count*aveMaxScore); diff>0; diff--, i++)
			scorers[i].setMaxScore(aveMaxScore + 1);

		for (AbstractScorer<TestSpec> each: scorers)
			each.setScoring(this.shouldScore);
		
		aggregateScorer = new AssignmentScorer("", 100, Arrays.asList(scorers));
		aggregateScorer.setShowPoints(this.shouldScore);
		aggregateScorer.setHeadfull(this.isHeadfull());
		aggregateScorer.run();
		return aggregateScorer;	
	}	
	
	
	
}
