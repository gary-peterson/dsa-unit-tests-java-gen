package common_object;

public class Assoc<K, V> {

	private K key;
	private V value;
	
	public static <T, U> Assoc<T,U> from(T key, U value) {
		return new Assoc<>(key, value);
	}

	public Assoc(K key, V value) {
		super();
		this.key = key;
		this.value = value;
	}

	public K getKey() {
		return key;
	}

	public void setKey(K key) {
		this.key = key;
	}

	public V getValue() {
		return value;
	}

	public void setValue(V value) {
		this.value = value;
	}

	public String toString() {
		return getKey() + " => " + getValue();
	}

	@Override
	public int hashCode() {
		return (31 * 7) + (getKey() == null ? 0 : getKey().hashCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Assoc))
			return false;
		return safeEquals(getKey(), ((Assoc<K, V>)o).getKey());
	}
	
	private boolean safeEquals(Object a, Object b)  {
		if (a==null ^ b==null)
			return false;
		if (a==null)
			return true;
		return a.equals(b);
	}	

}
