package scorer;

import java.lang.reflect.*;		//for "Method"

@SuppressWarnings({"rawtypes"}) //Not using generics
public interface ClassTest
{
	public String getTesteeClassName();
	public Class getTesteeClass();
	public Object getTestee();
	public void setTestee(Object testee);
	public Method firstMethodNamed(String methodName) throws Exception;
	public Log getLog();
	public void logException(String label, Throwable exception);
	
}