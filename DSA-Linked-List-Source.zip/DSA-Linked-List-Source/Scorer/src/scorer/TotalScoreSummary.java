package scorer;

import java.util.List;

public class TotalScoreSummary extends ScoreSummary {
	
	//============================================================	
	
	private int possiblePoints;
	private int points;
	
	//============================================================	
	
	public TotalScoreSummary(String label, int score , int possibleScore, int possiblePoints) {
		super(label, score, possibleScore);		
		this.possiblePoints = possiblePoints;		
		this.points = -1;
	}	
	
	public TotalScoreSummary(String label) {
		this(label, 0, 0, 0);
	}
	
	public TotalScoreSummary(String label, int possiblePoints) {
		this(label, 0, 0, possiblePoints);
	}	
	
	public TotalScoreSummary(ScoreSummary summary, int possiblePoints) {
		super(summary);		
		this.possiblePoints = possiblePoints;		
		this.points = -1;
	}	
	
	//============================================================	
	
	public void setPossiblePoints(int possiblePoints) {
		this.possiblePoints = possiblePoints;
	}
	
	//============================================================
	
	public int computeActualPoints() {
		/*
		 * if score percent is 80%
		 * And possiblePoints are 25
		 * Then actualPoints = 0.80 * 25 = 20
		 */
		int actualPoints;
		double scorePercent = getScorePercent() / 100.0; 
		actualPoints = (int)Math.round(scorePercent * this.possiblePoints);
		return actualPoints; 
	}
	
	public String toString() {
		//RectangleTesting -- Checks: 90 of 100 (90%) -- for 23 of 25 Points
		String ec = (isExtraCredit()) ? " (Extra Credit)" : "";
		return String.format("%-20s -- Checks222: %d of %d (%d%%) -- for %d of %d Points%s"
				, getLabel(), getScore(), getPossibleScore(), getScorePercent() 
				, getPoints(), this.possiblePoints, ec); 
	}	

	public String toPointsString(String label) {
		/*
		 * Total Points: 20 of 25
		 */
		return String.format("%s: %d of %d" 
					, label , getPoints(), this.possiblePoints); 
	}
	
	public void printSummaryOn(Log strm, String prefix) {
		/* We round each sub-summary, so points may
		 * be higher than scoring and %, so exclude the latter two
		 */		
		//out.println(this.toScoringString());
		//out.println(this.toPercentString(prefix + " Percent"));
		strm.println(this.toPointsString(prefix + " Points"));		
	}
	
	public void increaseBy(TotalScoreSummary other) {
		super.increaseBy(other);
		if (!other.isExtraCredit())
			this.possiblePoints += other.getPossiblePoints();
	}	
	
	public int getPossiblePoints() {
		return possiblePoints;
	}	
	
	public int getPoints() {
		if (this.points < 0)
			this.points = computeActualPoints();
		return this.points;
	}
	
	public int getPointsPercent() {
		int points, max, percentPassing;
		points = this.points;
		max = this.possiblePoints;
		percentPassing = (max > 0) 
				? (int) Math.round((points * 100.0) / max) 
				: 0;		
		return percentPassing;
	}	
	
	public void setPointsFrom(List<TotalScoreSummary> summaries) {
		//basic reduce is limited (accumulator type must match element type)
//		int totalPoints = 
//			summaries.stream()
//				.map(eachSummary -> eachSummary.getPoints())
//				.reduce(0, (accumulator, each) -> accumulator + each);
//		int totalPoints = 
//			summaries.stream()
//				.reduce(0, (accumulator, eachSummary) -> accumulator + eachSummary);		
		int sum = summaries.stream()
                .reduce(0,
                		(accumulator, summary) -> accumulator + summary.getPoints(),
                		(a, b) -> a + b);
//                		Integer::sum);
		this.points = sum;
	}
	
}
