package scorer;

import static java.lang.System.out;

import java.util.Arrays;
import java.util.List;

public class TextReadStreamLab {
	
	public static void main(String[] args) {
		TextReadStreamLab lab = new TextReadStreamLab();
		lab.play1();
		lab.sample_toLines();
		lab.sample_moveTo();
		lab.sample_upTo();
		lab.sample_rejectLines();
	}

	private void play1() {
		String str = "10 20 30 40";
		TextReadStream strm = new TextReadStream(str);
		out.println("Size: " + strm.size());
	}
	
	private void sample_toLines() {
		TextReadStream strm = new TextReadStream(fourLineString());
		List<String> lines = strm.toLines();
		out.println("Lines: " + lines.toString()); 
	}
	
	private void sample_moveTo() {
		out.println("\nsample_moveTo");
		TextReadStream strm = new TextReadStream(twoLineString());
		strm.moveTo("howdy");
		out.println("Next Line: " + strm.nextLine());
	}	
	
	private void sample_upTo() {
		TextReadStream strm;
		String s;
		out.println("\nsample_upTo");
		strm = new TextReadStream(twoLineString());
		strm.moveTo("howdy");
		s = strm.upTo("line");
		out.printf("upTo Result: [%s]%n", s);
		out.printf("Check: %s%n", s.equals("howdy now on "));
	}	
	
	private void sample_rejectLines() {
		TextReadStream strm, strm2;
		String[] subStrings;
		List<String> lines, lines2;

		subStrings = new String[] {"two", "four"};		
		strm = new TextReadStream(fourLineString());
		lines = strm.toLines();
		lines2 = TextReadStream.rejectLines(lines, Arrays.asList(subStrings));
		strm2 = new TextReadStream(lines2);
		out.println("\nsample_upTo");
		out.println("--Original:");
		out.println(strm.toString());
		out.println("--Pruned two|four:");
		out.println(strm2.toString());		
	}	
	
	//===============================================
	
	public String lineSeparator() { return System.lineSeparator(); }	
	
	protected String fourLineString()
	{
		String crlf = TextReadStream.lineSeparator();
		return ""
			+ "line one" + crlf
			+ "line two" + crlf
			+ "line three" + crlf
			+ "line four";
	}	
	
	protected String twoLineString()
	{
		String crlf = TextReadStream.lineSeparator();
		return ""
			+ "this is line 1" + crlf
			+ "howdy now on line 2" + crlf;
	}	

}
