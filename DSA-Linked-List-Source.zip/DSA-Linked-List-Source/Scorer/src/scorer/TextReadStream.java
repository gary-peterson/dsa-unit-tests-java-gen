package scorer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class TextReadStream {
	
	//============================================================
	//Ivars	
	
	char[] contents;
	int pos;
	
	//============================================================
	//Constructors	

	public TextReadStream(String str) {
		this.contents = str.toCharArray();
		this.pos = 0;
	}
	
	public TextReadStream(List<String> lines) {
		this(linesToString(lines));
	}	
	
	//============================================================
	//Public
	
	public String nextLine() {
		return upTo(lineSeparator());
	}
	
	public int size() {
		return contents.length;
	}

	public List<String> toLines() {
		return Arrays.asList(toString().split("\\r?\\n"));
	}
	
	public boolean moveTo(String subString) {
		//gpOptimize -- first search for first char match
		for (int i=getPos(); i<size(); i++)
			if (nextEquals(subString))
				return true;
			else
				skip();
		return false;
	}
	
	public String upTo(String subString) {
		int p1, p2;
		
		p1 = getPos();
		moveTo(subString);
		if (atEnd())
			p2 = getLastPos();
		else {
			p2 = getPos() - 1;
			skip(subString.length());
		}
		return copyFromTo(p1, p2);
	}
	
	private void skip(int by) {
		this.pos = getPos() + by;
	}
	
	public String next(int count) {
		//Return next <count> chars and increment position beyond end of copied chars
		int p1, p2;
		p1 = getPos();
		p2 = p1 + count - 1;
		setPos(p2 + 1);
		return copyFromTo(p1,  p2);
	}	

	public void skip() {
		skip(1);
	}

	public boolean nextEquals(String subString) {
		if (atEnd()) return false;
		int sz = subString.length();
		if (remaining() < sz)
			return false;
		return holdDuring(() -> { return basicNextEquals(subString); });
	}
	
	public String copyFromSize(int pos1, int length) {
		return copyFromTo(pos1, pos1+length-1);
	}
	
	public String copyFromTo(int pos1, int pos2) {
		return String.copyValueOf(copyCharsFromTo(pos1, pos2));
	}	
	
	public <Z> Z holdDuring(Supplier<Z> supplier) {
		int hold = getPos();
		Z result = supplier.get();
		setPos(hold);
		return result;
	}	
	
	private int remaining() {
		return size() - getPos();
	}

	private boolean atEnd() {
		return pos > getLastPos();
	}	
	
	//============================================================
	//Helpers	
	
	private boolean basicNextEquals(String subString) {
		String mySubString = copyFromSize(getPos(), subString.length());
		return mySubString.equals(subString);
	}
	
	private char[] copyCharsFromTo(int p1, int p2) {
		return copyChars(contents, p1, p2);
	}	

	private static void copyChars(char[] source, int p1, int p2, char[] target) {
		for (int i=p1, i2=0; i<=p2; i++, i2++)
			target[i2] = source[i];
	}
	
	private static char[] copyChars(char[] source, int p1, int p2) {
		char[] target = new char[p2 - p1 + 1];
		copyChars(source, p1, p2, target);
		return target;
	}	
	
	@SuppressWarnings({"unused"})
	private List<Character> stringToList(String s) {
		List<Character> chars = new ArrayList<>();
		for (char ch: s.toCharArray())
			chars.add(ch);
		return chars;
	}
	
	//============================================================
	//Accessing
	
	public int getPos() {
		return pos;
	}
	
	public int getLastPos() {
		return size() - 1;
	}	
	
	private void setPos(int pos) {
		this.pos = pos;
	}

	@Override
	public String toString() {
		return String.valueOf(contents);
	}	
	
	//============================================================
	//Accessing - Static	
	
	public static String lineSeparator() { return System.lineSeparator(); }	
	public static String crlf() { return lineSeparator(); }	
	
	public static List<String> rejectLines(List<String> lines, List<String> subStrings) {
		//Reject all lines that contain any of the subStrings
		List<String> newLines = new ArrayList<>();
		for (String line: lines)
			if (!stringIncludesAny(line, subStrings))
				newLines.add(line);
		return newLines;
	}
	
	public static boolean stringIncludesAny(String s, List<String> subStrings) {
		for (String subString: subStrings)
			if (s.contains(subString))
				return true;
		return false;
	}
	
	public static String linesToString(List<String> lines) {
		String s = "";
		for (String line: lines) {
			if (!s.isEmpty()) s += crlf();
			s += line;
		}
		return s;
	}		
	
	public static List<String> linesFrom(String s) {
		return (new TextReadStream(s)).toLines();
	}

}
