package scorer;

@FunctionalInterface
public interface BlockClosure {
    void evaluate();
}