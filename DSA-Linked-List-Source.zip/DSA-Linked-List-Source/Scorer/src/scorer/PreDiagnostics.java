package scorer;

import java.util.Arrays;
import java.util.List;

public class PreDiagnostics {

	private Log log;	
	String label;
	List<String> interfaceNames;
	List<String> classNames;

	public PreDiagnostics(String aLabel, List<String> interfaceNames, List<String> classNames) {
		this.label = aLabel;
		this.interfaceNames = interfaceNames;
		this.classNames = classNames;
		this.log = new Log("");		
	}

	private void checkExistance(List<String> typeNames, String label) {
		Log l = this.log;		
		if (!typeNames.isEmpty()) {
			l.cr();
			l.shortSeparator().p(label).cr();
			for (String type: typeNames) {
				boolean found = ClassTool.doesClassExist(type);
				String annotation = found ? "okay (found)" :"ERROR (NOT FOUND/NOT LOADABLE)";
				l.tab().p(type + " -- " + annotation);
			}
		}
	}

	public void go() {
		Log l = this.log;
		l
			.p(this.label)
			.cr()
			.thickSeparator()
			.p("Pre-Diagnostics")
			.cr()
			.p("Java Version: " + System.getProperty("java.version"))
//			.cr()
//			.p("Java Version History (fyi only):")
//			.indent("https://en.wikipedia.org/wiki/Java_(programming_language)#Versions")
//			.indent("https://en.wikipedia.org/wiki/Java_version_history")
//			.indent("https://www.oracle.com/technetwork/java/javase/8u201-relnotes-5209271.html")			
			.cr();
			
		l.shortSeparator().p("classpath").cr();		
		String classPathString = System.getProperty("java.class.path");
		for (String aClassPath: Arrays.asList(classPathString.split(";")))
				l.tab().p(aClassPath);
		
		checkExistance(this.interfaceNames, "Searching for Interfaces (CLASS files)");
		checkExistance(this.classNames, "Searching for Classes (CLASS files)");
		l.cr();
		//l.printToConsole();
	}

	public Log getLog() {
		return log;
	}

	public void setLog(Log log) {
		this.log = log;
	}

}
