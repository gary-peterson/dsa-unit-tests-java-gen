package scorer;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;

class TestTask implements Callable<Integer> {
	
	Method m;
	Object tester;
	MethodTest mt;	
	
	public TestTask(Method aTestMethod, Object aTester, MethodTest aMethodTest) {
		this.m = aTestMethod; 
		this.tester = aTester;
		this.mt = aMethodTest;		
	}
	@Override
	public Integer call() throws Exception {
		//02/13/2021		
		//mt.prn(Log.shortSeparatorString());
		//mt.prn("Starting Test: " + mt.getTesteeMethodName());
		try { m.invoke(tester, mt); }
		catch(Exception ex) {
			//mt.prn("");
			//System.out.println("-------------- Exception occurred --------------");			
			mt.recordException(false, "Exception occurred (See \"Exception Log\" below)");
			//mt.setMaxFailures(1);
			throw ex;
		}
//		try {
//			m.invoke(tester, mt);
//			//Thread.sleep(10*1000);
//			}
//		catch(InterruptedException ex) {
//			out.println("Task Interrupted (Timed Out). Exiting Test: " + mt.getTestSelector());
//		}
		
		return 1;
	}	
}
