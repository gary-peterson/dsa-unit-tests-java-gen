package scorer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/*
 Usage:
 	import static scorer.Tools.asList;
 	import static scorer.Tools.asString; 	
 	//...
 	List<Integer> list = asList(new int[] {10, 20, 30, 40});
 */

public class Tools {
	
	//-------------------------------------------------------	
	
	public static int cmp(int a, int b) {
		return Integer.compare(a, b);
	}	
	
	//-------------------------------------------------------
	/*Java's "trim()" is a little odd, it trims all chars <= 20x (lots of non-whitespace in there)
	so a few methods here
	remember:
		Java string literals use backslash as an escape character
		Because we want a literal backslash for escaping a regex symbol,
			we need to a double backslash wich results in a literal backslash in the literal
		Then we can folow that with the regex symbol
		For example for a space character:
			\\s
		See:
			https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html			
	*/
	
	public static String trimLeft(String s) {
		return s.replaceAll("^\\s+", "");
	}
	
	public static String trimRight(String s) {
		return s.replaceAll("\\s+$", "");
	}	
	
	public static String trim(String s) {
		return trimRight(trimLeft(s)); 
	}	
	
	public static boolean isBlank(String s) {
		if (s == null) return true;
		return s.isBlank();
	}	
	
	//-------------------------------------------------------	
	
	public static List<Integer> asList(final int... array) {
		//Usage: list = asList(array);
		return Arrays.stream(array).boxed().collect(Collectors.toList());
	}	
	
	public static String asString(final int... array) {
		//Usage: list = asList(array);
		return asList(array).toString();
	}	

	//-------------------------------------------------------
	
	public static int[] copy(final int[] source) {
		return Arrays.copyOf(source, source.length);
	}
	
	//-------------------------------------------------------
	//These helpers are especially helpful when running into cases
	//where local variables cannot be accessed from function blocks
	
	public static Supplier<String> str(final String prefix, final int[] array) {
		return () -> prefix + asString(array);
	}
	
	//-------------------------------------------------------
	
	//Stream helpers (simplifications when one operation is needed)
	
	public static <T, S> List<S> collect(List<T> list, Function<T, S> mapFct) {
		return
			list.stream()
				.map(mapFct)
				.collect(Collectors.toList());
	}
	
	public static <T, S> List<S> collectPreservingOrder(List<T> list, Function<T, S> mapFct) {
		//NOTE WELL -- "map" above may not change order -- needs lab play
		//in which case this method is redundant with collect 
		@SuppressWarnings("unchecked")
		List<S> newList = (List<S>)new ArrayList<Object>();
		for (T each: list)
			newList.add(mapFct.apply(each));
		return newList;
	}	
	
	public static <T> List<T> filter(List<T> list, Predicate<T> filterFct) {
		return
			list.stream()
				.filter(filterFct)
				.collect(Collectors.toList());
	}	
	
	public static List<Integer> range(int start, int stopPlusOne) {
		//Construct Stream
		//Stream<Integer> ints = IntStream.range(0, stopPlusOne).boxed();
		return
				(IntStream.range(start, stopPlusOne).boxed())
					.collect(Collectors.toList());
	}		
	
	public static <T> List<T> list(Stream<T> strm) {
		return strm.collect(Collectors.toList());
	}
	
}
