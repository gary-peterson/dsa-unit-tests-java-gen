package scorer;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ClassTool {
	
	@SuppressWarnings("rawtypes")
	public static boolean doesClassExist(String className) {
		Class aClass = null;
		try { aClass = Class.forName(className); }
		catch(Exception | Error ex) {
			aClass = null;
			//System.out.println("Error loading class: " + className);
			//System.out.println("Error: " + ex);
		}
		return aClass != null;
	}	
		
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Method findMethod(String selector, Class classo) throws Exception
	{
		//Note -- this method assumes singular method for selector (not overloaded method)
		Method m = null;
		try { m = classo.getDeclaredMethod(selector); }
		catch(Exception e) { throw e; }
		return m;
	}	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Method findMethod(String selector, Class c, Class... methodParamTypes)
	{
		Method method = null;
		try {
			method = c.getMethod(selector, methodParamTypes);
		}
		catch(Exception e) {}
		return method;
	}
	
	@SuppressWarnings("unchecked")	
	public static <T> T newInstance(T original) {
		//NOTE WELL -- THIS WILL FAIL IF original is immutable (at least for Arrays.asList()
		T newObject = null;
		try {
			Class<?> theClass = original.getClass();
			Constructor<?> constructor = theClass.getDeclaredConstructor();
			newObject = (T)constructor.newInstance();				
		} catch(Exception ex) {
			System.out.println(ex);
		}
		return newObject;
	}	

}
