package scorer;

//import static java.lang.System.out;

import java.util.List;

public class AggregateScorer {
	
	private Log log;
	private int maxPoints;
	private Log preDiagnosticsLog;
	private boolean showPoints;	//if false, out output is more pass/fail
	private boolean headfull;		//true if it has ui, otherwise assume report only	
	
	// ========================================================	
	// Constructors

	public AggregateScorer(int maxPoints) {
		super();
		this.log = new Log("");
		this.maxPoints = maxPoints;
		this.showPoints = true;
		this.headfull = true;
	}
		
	// ========================================================

	//todo -- why are we not using "totalPoints"
	public void printScoringSummary(List<TotalScoreSummary> subSummaries 
											,TotalScoreSummary totalSummary
											,@SuppressWarnings("unused") int totalPoints) {
		//log().printSectionSeparator("SCORING SUMMARY");
		//log().thickSeparator();
		log().printf("OVERALL SUMMARY%n%n");
		for (ScoreSummary eachSummary: subSummaries)
			log().println(eachSummary);
		totalSummary.printSummaryOn(getLog(), "Total");
	}	

	public Log getLog() {
		return log;
	}

	//alias	
	protected Log log() {
		return log;
	}
	
	protected void setLog(Log log) {
		this.log = log;
	}

	public int getMaxPoints() {
		return maxPoints;
	}
	
	public Log getPreDiagnosticsLog() {
		return preDiagnosticsLog;
	}

	public void setPreDiagnosticsLog(Log preDiagnosticsLog) {
		this.preDiagnosticsLog = preDiagnosticsLog;
	}
	
	//-------------------------------
	
	public boolean isShowPoints() {
		return showPoints;
	}

	public void setShowPoints(boolean showPoints) {
		this.showPoints = showPoints;
	}	
	
	public boolean isHeadfull() {
		return headfull;
	}

	public void setHeadfull(boolean headfull) {
		this.headfull = headfull;
	}	
	
}