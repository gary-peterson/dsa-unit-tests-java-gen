package scorer;

//import static java.lang.System.out;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

abstract public class MyObject extends Object {

	private ArrayList<String> errors;
	private boolean exceptionOccurred;
	
	public ArrayList<String> getErrors() {
		return errors;
	}
	
	public int getErrorsCount() {
		return this.errors.size();
	}

	public void setErrors(ArrayList<String> value) {
		errors = value;
	}

	// Constructors

	public MyObject() {
		super();
		this.setExceptionOccurred(false);
		setErrors(new ArrayList<String>());
	}

	// Services

	public boolean hasErrors() {
		return getErrors().size() > 0;
	}
	
	public void addError(String errorMessage) {
		println(errorMessage);
		this.basicAddError(errorMessage);
	}
	
	public void basicAddError(String errorMessage) {
		getErrors().add(errorMessage);
	}	

	public void addError(Exception ex, String errorMessage) {
		println(errorMessage);
		println(ex.getCause().toString());
		getErrors().add("Error: " + errorMessage);
		getErrors().add("Exception: " + ex.getCause().toString());
		// print("Errors size = " + getErrors().size());
	}

	// ---------------------------------------
	// Helper (convenience) methods
	
	public static <K, V> SimpleEntry<K, V> newKV(K key, V value) {
		return new SimpleEntry<>(key, value);
	}	

	protected MyObject printErrors() {
		for (String error : getErrors())
			getLog().println(error);
		return this;
	}

	public MyObject print(Object o) {
		getLog().print(o.toString());
		return this;		
	}

	public MyObject println(Object o) {
		getLog().println(o);
		return this;		
	}
	
	public MyObject printf(String template, Object... params) {
		getLog().printf(template, params);
		return this;
	}
	
	public MyObject prn(Object o) {
		//convenience alias
		println(o.toString());
		return this;		
	}	
	
//	{
//		/*
//		String input, patternString;
//		Pattern pattern;
//		Matcher matcher;
//		boolean foundMatch;
//
//		input = o.toString();
//		patternString = "^Constructed Rectangle object:";
//		pattern = Pattern.compile(patternString);
//		matcher = pattern.matcher(input);
//		foundMatch = matcher.find();
//		if (foundMatch)
//			return;
//		*/
//	}

	public void printSeparator() {
		Log l = getLog();
		l.println("");
		l.println("-----------------------------");
		l.println("");
	}
	
	protected String fmt(String template, Object...objects) {
		return String.format(template, objects);
	}

	// ---------------------------------------

	public static boolean isCollection(Object o) {
		if (o != null)
			return Collection.class.isAssignableFrom(o.getClass());
		else
			return false;
	}

	@SuppressWarnings({"rawtypes"}) //Not using generics	
	public static String bestDisplayString(Object o, Object other) {
		if (o == null)
			return "null";
		if (isCollection(o))
			return Arrays.toString(((Collection) o).toArray());
		if (other == null || (o.getClass() == other.getClass()))
			return o.toString();
		else
			return String.format("%s (%s)", o.toString(), o.getClass().getSimpleName());
	}
	
	abstract public Log getLog();

	protected boolean isExceptionOccurred() {
		return exceptionOccurred;
	}

	protected void setExceptionOccurred(boolean exceptionOccurred) {
		this.exceptionOccurred = exceptionOccurred;
	}
	
	

}
