package scorer;

public class BasicTestResult
{
	private Object expected;
	private Object actual;
	public BasicTestResult(Object e, Object a) {
		this.expected = e;
		this.actual = a;
	}
	public Object getExpected() { return this.expected; }
	public Object getActual() { return this.actual; }
	public boolean passed() {
		return MethodTest.equalsSafely(actual, expected);		
	}
}

