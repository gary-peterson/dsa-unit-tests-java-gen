package scorer;

import static java.lang.System.out;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

public class Log {
	
	private String label;

	private PrintStream stream;
	private ByteArrayOutputStream contents;
	
	public Log() {
		this.reset();
		this.label = "LOG";
	}
	
	public Log(String label) {
		this.reset();
		this.label = label;
	}
	
	//===============================================
	//Public Services
	
	public void reset() {
		this.contents = new ByteArrayOutputStream();
		this.stream = new PrintStream(this.contents);
	}	
	
	public void printToConsole() {
		printTo(out);
	}	
	
	public void printTo(PrintStream pstrm) {
		String s = this.getContentsString();
		if (s.isEmpty())
			return;
		//pstrm.println(separatorString());		
		if (!this.label.isEmpty()) 
			pstrm.printf("%s%n%n", this.label);
		pstrm.print(s);		
	}
		
	public Log println(Object o) {
		println(o.toString());
		return this;
	}	
	
	public Log p(Object o) {
		return this.println(o);
	}
	
	public Log indent(Object o) {
		return this.tab().p(o);
	}	
	
	public Log f(String template, Object... params) {
		return this.printf(template, params);
	}	
	
	public Log tab() {
		return this.printf("\t");
	}
	
	public Log tab(int count) {
		for (int i=count; i>0; i--)
			this.tab(0);
		return this;
	}	
	
	public Log printf(String template, Object... params) {
		print(String.format(template,  params));
		return this;		
	}	
	
	public Log println(String s) {
		this.stream.println(s);
		return this;		
	}
	
	public Log print(Log aLog) {
		aLog.printTo(getStream());
		return this;		
	}	
	
	public Log cr() {
		//Carriage Return
		this.println("");
		return this;		
	}	
	
	public Log cr(int count) {
		//Carriage Return
		for (int i=0; i<count; i++)
			this.cr();
		return this;		
	}	
	
	public void printIndented(String s, int indents) {
		List<String> lines = TextReadStream.linesFrom(s);
		for (int i=0; i<lines.size(); i++) {
			if (i>0) cr();
			for (int j=0; j<indents; j++)
				print("\t");
			print(lines.get(i));
		}
	}
	
	public Log print(String s) {
		this.stream.print(s);
		return this;		
	}	
	
	public Log separator() {
		this.println(separatorString());
		return this;		
	}	
	
	public Log shortSeparator() {
		this.println(shortSeparatorString());
		return this;		
	}	
	
	public Log thickSeparator() {
		this.println("===============================================================================  ");
		return this;		
	}
	
	public Log thickSeparator(int count) {
		for (int i=0; i<count; i++)
			this.thickSeparator();
		return this;		
	}	
	
	public Log starsSeparator() {
		this.println("*******************************************************************************");
		return this;		
	}	
	
	public Log starsSeparator(int count) {
		for (int i=0; i<count; i++)
			this.starsSeparator();
		return this;		
	}	
	
	public static String separatorString() {
		return "----------------------------------------";
	}	
	
	public static String shortSeparatorString() {
		return "----------";
	}	
	
	public void logException(String label, Throwable exception) {
		//separator();
		println("Exception occurred");
		println("During: " + label);
		
		//Throwable cause = exception.getCause();
		Throwable rootCause = getRootException(exception);
		
		if (rootCause != null) {
			StackTraceElement err = rootCause.getStackTrace()[0];		
			println("In Method: " + err.getMethodName());		
			printf("At Location: %s line %d%n", err.getFileName(), err.getLineNumber());
			printf("Cause: %s%n", rootCause.toString());
		}
		else {
			String str = exception.getMessage();
			if (str == null || str.isEmpty())
				str = exception.toString();
			printf("%s%n", str);					
		}
		
		Throwable traceSource = (rootCause != null) ? rootCause : exception;
		String callStackString = getStackTraceAsString(traceSource);
		String[] toExclude = {"Native Method", ".invoke", "sun.reflect.", ".reflect." 
								,".MethodTest.", ".ClassScorer.", "Scorer.run(", "Scorer.main("
								, "TestTask", "java.", ".run(", ".main("
								};
		callStackString = cleanupStackTrace(callStackString, Arrays.asList(toExclude));
		if (!callStackString.isEmpty()) {
			println("Call Stack:");
			printIndented(callStackString, 1);
		}
		cr(2);
	}
	
	@Override
	public String toString() {
		return this.getContentsString();
	}	
	
	public void printSectionSeparator(String label) {
		String separator = "****************************************";
		for (int i=0; i<=1; i++) 
			printf("%s%n", separator);
		printf("%s%n%n", label); 		
	}
	
//	private String getStackTraceAsString(Throwable ex) {
//		Log temp = new Log();
//		ex.printStackTrace(temp.getStream());
//		String str = temp.toString();
//		return str;
//	}	
	
	static String getStackTraceAsString(Throwable throwable){
		String crlf = TextReadStream.lineSeparator();
		String result = "";
		for (StackTraceElement each: throwable.getStackTrace())
			result += each.toString() + crlf;
		return result;
	}
	
	private static String cleanupStackTrace(String stackTrace, List<String> exclusionKeys) {
		//For each trace line, if we find any exclusionKeys on it, reject it
		TextReadStream strm2;
		List<String> lines, cleaned;
		
		lines = (new TextReadStream(stackTrace)).toLines();
		cleaned = TextReadStream.rejectLines(lines, exclusionKeys);
		if (cleaned.size() > 10)
			cleaned = cleaned.subList(0, 10);
		strm2 = new TextReadStream(cleaned);
		return strm2.toString();
	}
	
	public static Throwable getRootException(Throwable ex) {
		 Throwable root = ex;
		 while (root.getCause() != null)
			 root = root.getCause();
		 return root;
	}
	
	public void writeFile(String path) {
		writeFile(path, this.toString());
	}	
	
	public static void writeFile(String path , String contents)
	{
		try {
			PrintWriter writer = new PrintWriter(path, "UTF-8");
			writer.println(contents);
			writer.close();	}
			catch(Exception e) { out.println("EXCEPTION in writeFile() " + e.toString()); }			
	}	
	
	//===============================================
	//Accessors
	
	public void setContents(String s) {
		this.reset();
		this.print(s);
	}
	
	public String getContentsString() {
		return new String(this.contents.toByteArray(), StandardCharsets.UTF_8);		
	}
		
	public PrintStream getStream() {
		return stream;
	}
	
	public String getLabel() {
		return label;
	}	
	
	public int getSize() {
		return this.contents.size();
	}
	
	public void setLabel(String label) {
		this.label = label;
	}

}
