package scorer;

public class TestSpec {
	
	//=====================================================================
	//Ivars	
	
	private String label;
	private int maxScore;
	private String testeeClassName;
	private boolean extraCredit;
		
	//=====================================================================
	//Constructors
	
	public TestSpec(String label, String testeeClassName) {
		this(label, 0, testeeClassName);
	}	
	
	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}

	public TestSpec(String label, int maxScore, String testeeClassName) {
		this.label = label;
		this.maxScore = maxScore;
		this.testeeClassName = testeeClassName;
		this.extraCredit = false;
	}
	
	public TestSpec(int maxScore, String testeeClassName) {
		this(testeeClassName, maxScore, testeeClassName);
	}	

	//=====================================================================
	//Accessors

	public String getLabel() {
		return label;
	}

	public boolean isExtraCredit() {
		return extraCredit;
	}

	public void setExtraCredit(boolean extraCredit) {
		this.extraCredit = extraCredit;
	}

	public int getMaxScore() {
		return maxScore;
	}
	
	public String getTesteeClassName() {
		return testeeClassName;
	}	

}