package scorer;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

@SuppressWarnings({ "rawtypes", "unchecked" }) //Not using generics
public class MethodTest extends MyObject {
	// Note
	// testeeMethodName -- the model selector, sent to the model, e.g. #double()
	// testMethodName -- the test selector, sent to the tester, e.g. #test_double()

	private ClassTest classTest;
	public void setPoints(int points) {
		this.points = points;
	}

	private String testeeMethodName;
	private Method testeeMethod;
	private Object actual;
	private String testSelector;

	private int maxScore; // Max score for this problem (i.e. the "worth" of this problem)
	private int score; // Actual score

	private int possiblePoints; // Accumulated possible points (via our "record" methods)
	private int points; // Accumulated actual points
	
	private double percentOverride; // Optional percent (override) that overrides computed percent
									// Default is -1.0 (not used; i.e. no override)

	private int maxFailures; // Default is -1 (not used)
								// If > 0, 
								//	then do not perform any more tests if failures >= maxFailures

	private boolean passed;
	
	private Integer nextWorthOverride;

	public void reset() {
		this.possiblePoints = 0;
		this.points = 0;
		this.passed = false;
		this.setScore(-1);
		this.nextWorthOverride = null;
	}

	// Getting

	public ClassTest getClassTest() {
		return this.classTest;
	}

	public Method getTesteeMethod() {
		if (this.testeeMethod != null)
			return this.testeeMethod;
		// Otherwise try this
		Method m = null;
		try {
			m = this.getClassTest().firstMethodNamed(this.getTesteeMethodName());
		} catch (Exception ex) {
			addError("Exeption could not find method -- " + this.getTesteeMethodName());
			println("");
		}
		return m;
	}

	public String getTesteeMethodName() {
		return this.testeeMethodName;
	}

	public Object getActual() {
		return this.actual;
	}

	public int getMaxScore() {
		return this.maxScore;
	}

	public int getScore() {
		if (this.score == -1)
			this.setScore(this.scoreBlt());
		return this.score;
	}

	public String getTestSelector() {
		return this.testSelector;
	}

	public Object getTestee() {
		return this.getClassTest().getTestee();
	}

	// Setting

	public void setClassTest(ClassTest value) {
		this.classTest = value;
	}

	public void setTesteeMethod(Method value) {
		this.testeeMethod = value;
		if (value != null)
			this.setTesteeMethodName(value.getName());
	}

	public void setTesteeMethodName(String value) {
		this.testeeMethodName = value;
	}

	public void setActual(Object value) {
		this.actual = value;
	}

	public void setMaxScore(int value) {
		this.maxScore = value;
	}

	public int getMaxFailures() {
		return maxFailures;
	}

	public void setMaxFailures(int maxFailures) {
		this.maxFailures = maxFailures;
	}

	public void setScore(int value) {
		this.score = value;
	}

	public void setTestSelector(String value) {
		this.testSelector = value;
	}

	public void setTestee(Object testee) {
		this.getClassTest().setTestee(testee);
	}

	// Constructors

	public MethodTest(ClassTest classTest, String modelSelector, String testSelector) {
		super();
		setClassTest(classTest);
		setTesteeMethodName(modelSelector);
		setTestSelector(testSelector);
		Method m = null;
		// Don't need to match up on method for simulation type tests
		try {
			m = getClassTest().firstMethodNamed(modelSelector);
		} catch (Exception ex) {
		}
		// catch(Exception ex) { addError("Could not find method -- " + modelSelector);
		// }
		setTesteeMethod(m);
		// These two are optional, client may use these via our 'record' method.
		// If they are used (i.e. if possiblePoints>0) then they will govern the
		// scoring for this problem.
		this.possiblePoints = 0;
		this.points = 0;
		this.passed = false;
		this.setScore(-1);
		this.percentOverride = -1.0;
		setMaxFailures(-1);
		this.nextWorthOverride = null;
	}

	// Services

	public void record(int awardedPoints, int maxPoints) {
		if (hasMaxFailures())
			return;
		this.points += awardedPoints;
		this.possiblePoints += maxPoints;
	}

	public void record(boolean correct, int maxPoints) {
		if (hasMaxFailures())
			return;
		this.points += (correct ? maxPoints : 0);
		this.possiblePoints += maxPoints;
	}

	public void record(boolean correct) {
		this.record(correct, null);
	}
	
	public int getNextScoreWorth() {
		//Allow one-time override
		if (this.nextWorthOverride != null) {
			int worth = this.nextWorthOverride;
			this.nextWorthOverride = null;
			return worth;
		}
		//default worth
		return 1;
	}
	
	public void setNextWorthOverride(int worth) {
		this.nextWorthOverride = worth;
	}	
	
	public void worth(int worth) {
		this.setNextWorthOverride(worth);
	}	
	
	public void record(boolean correct, String errorMsg) {
		record(correct, 1, errorMsg);
	}

	public void record(boolean correct, int maxPoints, String errorMsg) {
		// Assume maxPoints=1 for this test event
		// gptodo -- capture and track errors
		if (hasMaxFailures())
			return;
		if (!correct && errorMsg != null) {
			printOutTestInfo(null);
			addError("FAILED: " + errorMsg);
			println("");
		}
		this.record(correct, maxPoints);
	}

	public void record(Object actual, Object expected, String errorMsg, int maxPoints, Object aTestee) {
		record(actual, expected, () -> errorMsg, maxPoints, aTestee);
	}

	public void record(Object actual, Object expected, Supplier<String> msgSupplier, int maxPoints, Object aTestee) {
		if (hasMaxFailures())
			return;
		boolean okay = equalsSafely(actual, expected);
		Object testee = aTestee != null ? aTestee : this.getTestee();
		if (!okay) {
			prn("");
			if (testee != null)
				println("Tested Object: " + testee.toString());
			//This is redundant with test selector printed header
			//println("Test Name: " + this.getTesteeMethodName());
			if (msgSupplier != null)
				addError("Error: " + msgSupplier.get());
			println("Expected: " + bestDisplayString(expected, actual));
			println("Actual: " + bestDisplayString(actual, expected));
			println("");
		}
		this.record(okay, maxPoints);
	}

	public void recordCheckingApprox(double actual, double expected, double tolerance, String errorMsg, int maxPoints,
			Object aTestee) {
		if (hasMaxFailures())
			return;
		double diff = Math.abs(expected - actual);
		boolean okay = diff <= tolerance;
		if (!okay) {
			printOutTestInfo(aTestee != null ? aTestee : this.getTestee());
			println("Expected: " + bestDisplayString(expected, actual));
			println("Actual: " + bestDisplayString(actual, expected));
			if (errorMsg != null)
				addError("Message: " + errorMsg);
			println("");
		}
		this.record(okay, maxPoints);
	}

	public void record(Object actual, Object expected, String errorMsg, int maxPoints) {
		this.record(actual, expected, errorMsg, maxPoints, null);
	}

	public void record(Object actual, Object expected, String errorMsg) {
		record(actual, expected, errorMsg, null);
	}

	public void record(Object actual, Object expected, String errorMsg, Object aTestee) {
		record(actual, expected, errorMsg, aTestee, "Actual", "Expected", false);
	}
	
	public void recordWithMessage(Object actual, Object expected, Supplier<String> errorMsgFct) {
		recordWithMessage(actual, expected, errorMsgFct, null, "Actual", "Expected", false);
	}	
	
	public void recordGE(int actual, int expected, String msg, Object aTestee) {
		String msg2 = String.format("%d >= %d", actual, expected);
		record(actual >= expected, true, (msg + " -- " + msg2), aTestee, "Actual", "Expected", false);		
	}	
	
	public void recordWithMessage(Object a, Object b, Supplier<String> errorMsgFct, Object aTestee,
						String labelForA, String labelForB, boolean reverseDisplayOrder) {
		if (hasMaxFailures())
			return;
		boolean okay = equalsSafely(a, b);
		if (!okay) {
			printOutTestInfo(aTestee != null ? aTestee : this.getTestee());
			if (reverseDisplayOrder) {
				println(labelForB + ": " + bestDisplayString(b, a));
				println(labelForA + ": " + bestDisplayString(a, b));				
			}
			else {
				println(labelForA + ": " + bestDisplayString(a, b));
				println(labelForB + ": " + bestDisplayString(b, a));
			}
			if (errorMsgFct != null) {
				String errorMsg = errorMsgFct.get();
				if (!Tools.isBlank(errorMsg))
					addError("FAILED: " + errorMsg);
			}
			println("");
		}
		this.record(okay);
	}
	
	public void record(Object a, Object b, String errorMsg, Object aTestee,
			String labelForA, String labelForB, boolean reverseDisplayOrder) {	
		recordWithMessage(a, b, () -> errorMsg, aTestee, labelForA, labelForB, reverseDisplayOrder);
	}
	
	public void printOutTestInfo(Object testee) {
		String testName;
		testName = this.getTestSelector();
		if (testName.isEmpty())
			testName = this.getTesteeMethodName();
		println("Test Name: " + testName);
		if (testee != null) {
			try {
				println("Tested Object: " + testee.toString());
			} catch (Exception | Error ex) {
				println("Tested Object: EXCEPTION occurred during toString()");
				this.classTest.logException("toString in " + this.getTestSelector(), ex);
			}
		}
	}

	public void record(Object actual, Object expected) {
		record(actual, expected, null);
	}
	
	public Class<?> getMethodReturnType(Class c, String methodName, Class<?>... methodParamTypes) {
		Method m = findMethod(c, methodName, methodParamTypes);
		if (m == null)
			return null;
		return m.getReturnType();
	}
	
//	public String getMethodReturnTypeName(Class c, String methodName, Class<?>... classes) {
//		return getMethodReturnTypeNameWith(c, methodName, classes);
//	}	
	
	public String getMethodReturnTypeName(Class c, String methodName, Class<?>... methodParamTypes) {
		Class<?> returnType = getMethodReturnType(c, methodName, methodParamTypes);
		if (returnType == null)
			return null;
		else
			return returnType.getSimpleName();
	}	

	public boolean checkMethodSignature(Class c, String methodName, Class[] methodParamTypes) {
		return checkMethodSignature(c, methodName, methodParamTypes, false);
	}

	public boolean checkMethodSignature(Class c, String methodName, Class[] methodParamTypes,
			boolean shouldSetTesteeMethod) {
		Method m = findMethod(c, methodName, methodParamTypes);
		if (shouldSetTesteeMethod)
			this.setTesteeMethod(m);
		if (m != null)
			return true;
		List<String> paramTypes = new ArrayList<String>();
		for (Class eachClass : methodParamTypes)
			paramTypes.add(eachClass.getSimpleName());
		String paramsString = cleanupParamString(Arrays.toString(paramTypes.toArray()));
		String msg = String.format("Method signature not found: \"%s(%s)\"", methodName, paramsString);
		this.record(false, msg);
		return false;
	}

	public boolean checkAndApplyMethodSignature(Class c, String methodName, Class[] methodParamTypes) {
		return checkMethodSignature(c, methodName, methodParamTypes, true);
	}

	public boolean checkConstructorSignature(Class c, Class[] methodParamTypes) {
		if (includesConstructor(c, methodParamTypes))
			return true;
		List<String> paramTypes = new ArrayList<String>();
		for (Class eachClass : methodParamTypes)
			paramTypes.add(eachClass.getSimpleName());
		String paramsString = cleanupParamString(Arrays.toString(paramTypes.toArray()));
		String msg = String.format("Constructor signature not found: \"%s(%s)\"", c.getSimpleName(), paramsString);
		this.record(false, msg);
		return false;
	}

	public boolean checkMethodSignature(Class c, String methodName) {
		return checkMethodSignature(c, methodName, new Class[] {});
	}

	public boolean checkAndApplyMethodSignature(Class c, String methodName) {
		return checkAndApplyMethodSignature(c, methodName, new Class[] {});
	}

	// Processors

	private static String exceptionLogReferenceLabel() {
		return "(See \"Exception Log\" report section)";
	}

	private boolean hasMaxFailures() {
		int max = getMaxFailures();
		if (max <= 0)
			return false;
		return this.getErrorsCount() > max;
	}

	public void perform() {
		// Perform the test and put the execution result in #actual
		if (hasMaxFailures())
			return;
		Object returnValue = null;
		try {
			returnValue = getTesteeMethod().invoke(getClassTest().getTestee());
		} catch (Exception ex) {
			addError(exeptionErrorPrefix() + getTesteeMethodName() + " " + exceptionLogReferenceLabel());
			println("");
			this.classTest.logException(this.getTestSelector(), ex);
		}
		setActual(returnValue);
	}

	/*
	 * Doesn't work because we may have arg type like Integer.class and we need
	 * int.class, etc. protected Method findMethodWithArgType(Class argType) {
	 * return findMethod(getClassTest().getTestee().getClass(),
	 * this.getTesteeMethodName(), new Class[] {argType}); }
	 */

	public void perform(Object arg1) {
		// Perform the test and put the execution result in #actual
		if (hasMaxFailures())
			return;
		Object returnValue = null;
		try {
			returnValue = getTesteeMethod().invoke(getClassTest().getTestee(), arg1);
		} catch (Exception ex) {
			addError(exeptionErrorPrefix() + getTesteeMethodName() + " " + exceptionLogReferenceLabel());
			this.classTest.logException(this.getTestSelector(), ex);
		}
		setActual(returnValue);
	}

	public void perform(Object arg1, Object arg2) {
		// Perform the test and put the execution result in #actual
		if (hasMaxFailures())
			return;
		Object returnValue = null;
		try {
			returnValue = getTesteeMethod().invoke(getClassTest().getTestee(), arg1, arg2);
		} catch (Exception ex) {
			addError(exeptionErrorPrefix() + getTesteeMethodName() + " " + exceptionLogReferenceLabel());
			this.classTest.logException(this.getTestSelector(), ex);
		}
		setActual(returnValue);
	}

	public void perform(Object arg1, Object arg2, Object arg3) {
		// Perform the test and put the execution result in #actual
		if (hasMaxFailures())
			return;
		Object returnValue = null;
		try {
			returnValue = getTesteeMethod().invoke(getClassTest().getTestee(), arg1, arg2, arg3);
		} catch (Exception ex) {
			addError(exeptionErrorPrefix() + getTesteeMethodName() + " " + exceptionLogReferenceLabel());
			this.classTest.logException(this.getTestSelector(), ex);
		}
		setActual(returnValue);
	}

	// convenience perform methods
	public void performAndScore(int possiblePoints, Object expectedValue, Object testee) {
		performAndScore(possiblePoints, expectedValue, testee, "");
	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, String msg) {
		if (hasMaxFailures())
			return;
		this.setTestee(testee);
		this.perform();
		this.record(this.getActual(), expectedValue, this.getTesteeMethodName() + " " + msg, possiblePoints, null);
	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, Supplier<String> msgSupplier) {
		if (hasMaxFailures())
			return;
		this.setTestee(testee);
		this.perform();
		this.record(this.getActual(), expectedValue, msgSupplier, possiblePoints, null);

	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, Object arg1) {
		this.performAndScore(possiblePoints, expectedValue, testee, arg1, String.format("(%s)", arg1));
	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, Object arg1, String msg) {
		if (hasMaxFailures())
			return;
		this.setTestee(testee);
		this.perform(arg1);
		String delim = msg.startsWith("(") ? "" : " ";
		this.record(this.getActual(), expectedValue, (this.getTesteeMethodName() + delim + msg), possiblePoints, null);
	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, Object arg1, Object arg2) {
		if (hasMaxFailures())
			return;
		this.setTestee(testee);
		this.perform(arg1, arg2);
		String argsString = String.format("(%s, %s)", arg1, arg2);
		this.record(this.getActual(), expectedValue, this.getTesteeMethodName() + argsString, possiblePoints, null);
	}

	public void performAndScore(int possiblePoints, Object expectedValue, Object testee, Object arg1, Object arg2,
			Object arg3) {
		if (hasMaxFailures())
			return;
		this.setTestee(testee);
		this.perform(arg1, arg2, arg3);
		String argsString = String.format("(%s, %s, %s)", arg1, arg2, arg3);
		this.record(this.getActual(), expectedValue, this.getTesteeMethodName() + argsString, possiblePoints, null);
	}

	public void record(BlockClosure setupBlock, Supplier<BasicTestResult> testBlock, String errorMessage) {
		setupBlock.evaluate();
		BasicTestResult testResult = testBlock.get();
		String resolvedMessge = testResult.passed() ? ""
				: String.format(errorMessage, testResult.getExpected(), testResult.getActual());
		this.record(testResult.passed(), resolvedMessge);
	}

	// ===================================================================

	// Services

	public boolean passed() {
		return getScore() == getMaxScore();
	}

	public boolean hasName(String methodNm) {
		return getTesteeMethodName() == methodNm;
	}

	public String resultStatus() {
		int percent = getPercent();
		// print(String.format("percent = %d", percent));
		if (percent == 0)
			return "FAILED";
		if (percent < 100)
			return "PARTIAL";
		else
			return "passed";
	}

	public String asDisplayString(boolean scoring) {
		String separator = " -- ", passedString = resultStatus(), postfix = "";

		int ecount = getErrors().size();

		if (!isRunnable())
			postfix = " (NOT RUNNABLE)" + " (" + ecount + " errors)";

		if (getPercent() < 100) {
			if (!this.isExceptionOccurred() && getErrorsCount() > 0)
				;	//postfix += String.format(" (checks failed)");				
			else
				;	//postfix += " (exceptions/timeout)";
		//getErrorsCount()
		}

		//changed to getTestSelectorFormatted from getTesteeMethodName()
		String s = this.testSelector + separator + passedString;
		if (!scoring) return s + postfix;
		return s + separator + getScore() + " of " + getMaxScore() + postfix;
	}

	public void setPassed(boolean argPassed) {
		this.passed = argPassed;
		// setScore(passed ? getMaxScore() : 0);
	}

	public boolean isRunnable() {
		// gpNeedsThought -- errors may simply indicate a test failure
		return true;
		// return !hasErrors();
	}

	private int scoreBlt() {
		if (hasMaxFailures())
			return 0;
		int possiblePoints = this.possiblePoints;
		int maxScore = this.maxScore;

		// Alternative 1
		if (possiblePoints == 0)
			return this.passed ? maxScore : 0;

		// Alternative 2
		int points = this.points;
		double doubleScore = ((double) points / possiblePoints) * maxScore;
		int score = (int) Math.round(doubleScore);
		return score;
	}

	public void setFailuresThreshold(int failuresThreshold) {
		/*Total checks count doesn't matter in this case, could be 10, 100, 1M, ...
		 * Only looling at failuresThreshold 
		 * e.g. failuresThreshold = 4
		 * 	failures	failed(%)	passed(%)
		 * 		0			0			100
		 * 		1			25			75				1/4 -> 25%
		 * 		2			50			50				1/2 -> 50%
		 * 		3			75			25
		 * 		4			100			0
		 * 		5 etc		100			0
		*/
		this.scoreHammerTesting(failuresThreshold);
	}

	public void scoreHammerTesting(int failuresThreshold) {
		/*
		 * Hammer testing 
		 * We hammer n tests against model 
		 * We count failuresCount 
		 * We compare failuresCount versus failuresThreshold
		 *  Computation: 
		 *  	reductionFraction
		 * 			= (failuresCount / failuresThreshold) 
		 * 				min: 1.0
		 *  reductionPercent = * reductionFraction * 100.0
		 *  passingPercent = 100.0 - reductionPercent
		 */
		int failuresCount;
		double reductionFraction, reductionPercent, passingPercent;
		failuresCount = this.possiblePoints - this.points;
		reductionFraction = (double) failuresCount / failuresThreshold;
		reductionFraction = Math.min(reductionFraction, 1.0);
		reductionPercent = reductionFraction * 100.0;
		passingPercent = 100.0 - reductionPercent;
		this.percentOverride = passingPercent;

		// gptodo -- seems we may not need percentOverride?
		// This class needs much cleanup

		double doubleActualScore = (getPercent() * 0.01) * this.maxScore;
		int newScore = (int) Math.round(doubleActualScore);
		setScore(newScore);
		// print("testeeMethodName: " + this.testeeMethodName);
		// print("this.score: " + this.score);
	}

	private int getPercent() {
		if (this.percentOverride >= 0)
			return (int) Math.round(this.percentOverride);

		int maxScore, actualScore;

		// print("points: " + points);
		// print("possiblePoints: " + possiblePoints);

		maxScore = this.maxScore;
		actualScore = this.getScore();
		//int failures = this.possiblePoints - this.points;
		// print("FAILURES: " + failures);
		// print("maxScore: " + maxScore);
		// print("actualScore: " + actualScore);
		double doublePercent = ((double) actualScore / maxScore) * 100;
		// print(String.format("Percent (actual): %.2f", doublePercent));
		int percent = (int) Math.round(doublePercent);
		// print("Percent (rounded): " + percent);
		return percent;
	}

	// Helpers

	// ===================================================================

	public static Method findMethod(Class c, String methodName, Class[] methodParamTypes) {
		/*
		 * Pros/Cons getMethod should find inherited getDeclaredMethod does not get
		 * inherited getMethod only finds public getDeclaredMethod finds all access
		 * types (or at least more than just public) NOTE WELL The "invoke" only works
		 * on public
		 */
		Method method = null;
		try {
			method = c.getMethod(methodName, methodParamTypes);
		} catch (Exception e) {
		}
		return method;
	}

	public static Method findMethod(Class c, String methodName) {
		return findMethod(c, methodName, new Class[] {});
	}

	public static boolean includesMethod(Class c, String methodName, Class[] methodParamTypes) {
		return findMethod(c, methodName, methodParamTypes) != null;
	}

	public static boolean includesMethod(Class c, String methodName) {
		return findMethod(c, methodName) != null;
	}

	// ------------------------------------------------------

	public static String returnTypeFor(Class c, String methodName, Class[] methodParamTypes) {
		Method m = findMethod(c, methodName, methodParamTypes);
		return m != null ? m.getReturnType().getSimpleName() : "UNKNOWN (method not found)";
	}

	// ------------------------------------------------------

	public static Constructor findConstructor(Class c, Class[] methodParamTypes) {
		Constructor constructor = null;
		try {
			constructor = c.getConstructor(methodParamTypes);
		} catch (Exception e) {
		}
		return constructor;
	}

	public static boolean includesConstructor(Class c, Class[] methodParamTypes) {
		return findConstructor(c, methodParamTypes) != null;
	}

	public static boolean hasEmptyConstructor(Class c) {
		return (c.getConstructors().length == 0) || (findConstructor(c, new Class[] {}) != null);
	}

	// ------------------------------------------------------

	public static String cleanupParamString(String paramString) {
		// paramString "[String, int]" => "String, int"
		int l = paramString.length();
		if (l < 2)
			return paramString;
		int lastIndex = l - 1;
		if ((paramString.charAt(0) == '[') && (paramString.charAt(lastIndex) == ']'))
			return paramString.substring(1, lastIndex);
		else
			return paramString;
	}

	public static boolean equalsSafely(Object actual, Object expected) {
		//If ONLY one is null, return false
		if ((actual == null) ^ (expected == null))
			return false;
		//If either null, now we know both are null, but we'll be sure and check both
		//If both null, return true
		if (actual == null && expected == null)
			return true;
		
		Object target = actual, param = expected;
		//BaselineTestObject has special behavior in "equals", so we want to use instances as target
		if (expected instanceof BaselineTestObject) {
			target = expected;
			param = actual;
		}
		return target.equals(param);		
	}

	@Override
	public Log getLog() {
		return this.classTest.getLog();
	}

	public String getTestSelectorFormatted() {
		//obsolete
		//e.g. for "test_foo" return "foo test"
		String prefix, selector;
		prefix = "test_";
		selector = this.testSelector;
		if (selector.startsWith(prefix))
			return selector.substring(prefix.length()); //+ " test";
		else
			return selector;
	}

	public static String exeptionErrorPrefix() {
		return "Exeption executing -- ";
	}
	
	public boolean hasReturn(Class c, String methodName, Class<?>... methodParamTypes) {
		//Return true if method <methodName> returns a value (i.e. does not a "void" return type)
		String returnType; 
		returnType = this.getMethodReturnTypeName(c, methodName, methodParamTypes);
		if (returnType != null)
			return !returnType.equalsIgnoreCase("void");
		else
			return false;
	}

	@Override
	public String toString() {
		return this.getTesteeMethodName()
			+ " "
			+ this.getScore()
			+ " "
			+ this.getPercent()
			+ "%";
	}

	public void recordException(boolean b, String string) {
		this.record(b, string);
		this.setExceptionOccurred(true);
	}

	public int getPoints() {
		return points;
	}

	public void setAsFailed(String error) {
		//timeout etc occurred, client wants to override all scoring for this mt
		//and just set as failed
		record(false, error);
		setMaxFailures(1);
		setFailuresThreshold(1);
		//methodTest.setPassed(false);		
		//methodTest.setPoints(0);
		//methodTest.setScore(0);		
	}
	
	//---------------------------------------------------
	//Junit 5 protocol
	
	public void assertEquals(Object expected, Object actual, Object message) {
		this.assertEquals(actual, expected, () -> message.toString());
	}
	
	public void assertEquals(Object expected, Object actual, Supplier<String> errorMsgFct) {
		this.recordWithMessage(actual, expected, errorMsgFct);
	}	
	
	public void assertEquals(Object expected, Object actual) {
		this.assertEquals(expected, actual, null);
	}	
	
	public void assertTrue(boolean actual, Object message) {
		this.assertEquals(true, actual, () -> message.toString());
	}
	
	public void assertTrue(boolean actual, Supplier<String> errorMsgFct) {
		this.assertEquals(true, actual, errorMsgFct);
	}	
	
	public void assertTrue(boolean actual) {
		this.assertEquals(true, actual, () -> null);
	}	
	
	public void assertFalse(boolean actual) {
		this.assertTrue(!actual);
	}	
	
	public void assertExceptionIn(BlockClosure fct, Supplier<String> errorMsgFct) {
		this.assertTrue(isExceptionIn(fct), errorMsgFct);
	}
	
	public void assertExceptionIn(BlockClosure fct, String errorMsg) {
		this.assertExceptionIn(fct, () -> errorMsg);
	}	
	
	//---------------------------------------------------
	// Helpers
	
	private boolean isExceptionIn(BlockClosure fct) {
		try { fct.evaluate(); }
		catch(Exception ex) { return true; }
		return false;
	}	
	
}

//==============================================================
