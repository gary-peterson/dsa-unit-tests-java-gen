package scorer;

public class BaselineTestObject {

}
