package scorer;

public class ScorerTools {
	

	/*Convenience
	 * Raw: 			new Class[] {int.class}
	 * Simplified: 		newClassArray(int.class)
	 */
	
	@SuppressWarnings("rawtypes") //Class[] array is mixed types
	public static Class[] newClassArray(Class...classes) {
		return classes;
	}
	
}
