package scorer;

@SuppressWarnings("all") //Heap pollution warning false flag
@FunctionalInterface

public interface EvaluableVarargs<DT, RT> {
    RT apply(DT... args);
}