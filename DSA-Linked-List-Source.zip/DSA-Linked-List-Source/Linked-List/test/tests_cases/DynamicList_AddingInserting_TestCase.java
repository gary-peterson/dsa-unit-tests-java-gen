
/*
    DynamicList_OneElement_Scorer.java.java
    02/14/21
    
    Unit: emty list (individual tests will modify)
*/
package tests_cases;

import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import linearpub.DynamicList;
import scorer.MethodTest;
import testutil.BaselineList;
import testutil.Thing;

public class DynamicList_AddingInserting_TestCase extends Abstract_DynamicList_TestCase<Thing> {

	// ============================================
	// Constructors

	public DynamicList_AddingInserting_TestCase(int maxPoints, Supplier<DynamicList<Thing>> emptyListGenerator,
			String constructUnitSnippet) {
		super(maxPoints, emptyListGenerator, "Testing Methods That Add/Insert", constructUnitSnippet);
	}
	
	public DynamicList_AddingInserting_TestCase() {
		this(100, null, null);
	}	

	// ============================================
	// Housekeeping / Test Admin

	protected String[] getTestNames() {
		return new String[] { 
				"test_construction", 
				"test_addFirst", 
				"test_addLast", 
				"test_add", 
				"test_insert"
		};
	}

	// =====================================================
	// Setup

	public void beforeEach() {
		this.unit = this.getEmptyListGenerator().get();
	}

	// =====================================================
	// Helpers	

	private BaselineList<Thing> newBaselineList(int first, int last, BiConsumer<BaselineList<Thing>, Thing> adder) {
		BaselineList<Thing> list = new BaselineList<>();
		for (int id = first; id <= last; id++)
			adder.accept(list, new Thing(id));
		return list;
	}

	// =====================================================
	// Tests

	public void test_construction(MethodTest mt) {
		mt.assertTrue(unit != null);
	}

	public void test_addFirst(MethodTest mt) {
		for (int id = this.defaultStart(); id <= this.defaultEnd(); id++)
			unit.addFirst(new Thing(id));
		BaselineList<Thing> expected;
		expected = newBaselineList(this.defaultStart(), this.defaultEnd()
				, (list, elem) -> list.addFirst(elem));
		mt.assertEquals(expected, unit, () -> unit.toString());
	}

	public void test_addLast(MethodTest mt) {
		for (int id=this.defaultStart(); id<=this.defaultEnd(); id++)
			unit.addLast(new Thing(id));
		BaselineList<Thing> expected;
		expected = newBaselineList(this.defaultStart(), this.defaultEnd()
					, (list, elem) -> list.addLast(elem));
		mt.assertEquals(expected, unit, () -> unit.toString());		
	}
	
	public void test_add(MethodTest mt) {
		for (int id=this.defaultStart(); id<=this.defaultEnd(); id++)
			unit.add(new Thing(id));
		BaselineList<Thing> expected;
		expected = newBaselineList(this.defaultStart(), this.defaultEnd()
					, (list, elem) -> list.add(elem));
		mt.assertEquals(expected, unit, () -> unit.toString());		
	}
	
	public void test_insert(MethodTest mt) {
		unit.add(new Thing(1001));		
		BaselineList<Thing> expected = new BaselineList<Thing>();
		expected.add(new Thing(1001));		
		Random rand = new Random();
		int firstId = defaultStart();
		for (int offset=0+1; offset<=this.defaultSize(); offset++) {
			int randomIndex = rand.nextInt(offset);
			expected.insert(randomIndex, new Thing(firstId+offset));
			unit.insert(randomIndex, new Thing(firstId+offset));
		}
		mt.assertEquals(unit.size(), expected.size(), "size check");
		mt.worth(4);
		mt.assertEquals(unit, expected);
	}		

	//----------------------------------------------------
	//Test Bas	

	//----------------------------------------------------
	//Helper Methods	

	private int defaultStart() {
		return 1001;
	}

	private int defaultEnd() {
		return 1100;
	}
	
	private int defaultSize() {
		return defaultEnd() - defaultStart() + 1;
	}

	//----------------------------------------------------
	//Main entry point

	public static void main(String[] args) {
		//TODO
		DSAA2Scorer.main(args);
	}

}
