package unit_test.unit_test_model;

import java.util.List;

import scorer.AssignmentScorer;

public interface UnitTestManagerIdea {

	//Getting
	
	List<Class<?>> testCases();	

	List<String> testCaseNames();	

	List<String> testNamesIn(String testCaseName);
	
	//Running
	
	String currentTestLabel();

	AssignmentScorer run(boolean aShowErrorsOnly, List<String> testCaseNames, List<String> testsNames);
	
}
