package unit_test.unit_test_ui;

import java.awt.Color;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;

import scorer.AssignmentScorer;
import unit_test.unit_test_model.UnitTestManagerIdea;

public class UnitTestController extends Controller {
	
	private ExecutorService e;
	boolean running;

	public UnitTestController(Container view) {
		super(view);
		this.running = false;
	}

	//===========================================================================	

	public void windowOpened() {
		updateUiStates();
		resetStatus();
	}

	//===========================================================================

	private boolean hasOneTestCaseSelected() {
		return this.testCasesElem().getSelectedValuesList().size() == 1;
	}

	//===========================================================================	

	public void changedTestCases(@SuppressWarnings("unused") ListSelectionEvent e) {
		this.ncTests();
		//JList list = (JList) e.getSource();
		//this.resetStatus();
		this.updateUiStates();
	}

	public void changedTests(@SuppressWarnings("unused") ListSelectionEvent e) {
		//this.resetStatus();
	}

	//----------------------------------------------------
	//needsContents

	private void ncTests() {
		this.testsElem().setListData(deriveTestNames());
	}

	//----------------------------------------------------
	//needsContents - action controls
	
	private void ncScore() {
		//not used
	}	

	private void ncSelectAllCases() {
		this.selectAllCasesElem().setEnabled(!this.running);
	}

	private void ncSelectAllTests() {
		this.selectAllTestsElem().setEnabled(
				!this.running && hasOneTestCaseSelected());
	}

	private void ncRun() {
		this.runElem().setEnabled(!this.running && hasSelectedTestCase());
	}

	private void updateUiStates() {
		//ncTests();
		ncSelectAllCases();
		ncSelectAllTests();
		ncRun();
		ncScore();
		this.testCasesElem().setEnabled(!this.running);
		this.testsElem().setEnabled(!this.running);		
	}

	//----------------------------------------------------
	//private	

	private String[] deriveTestNames() {
		if (this.hasOneTestCaseSelected())
			return (testMgr().testNamesIn(this.testCasesElem().getSelectedValue())).toArray(String[]::new);
		return new String[] {};
	}

	private boolean hasSelectedTestCase() {
		return !this.testCasesElem().isSelectionEmpty();
	}

	//----------------------------------------------------
	//action click handlers

	public void clickedSelectAll(JList<String> list) {
		list.setSelectionInterval(0, list.getModel().getSize() - 1);
	}

	private void finishThread() {
		this.running = false;
		this.updateUiStates();
	}
	
	public void clickedRun() {
		class BackgroundTask implements Runnable {
			@Override
			public void run() {
				AssignmentScorer scorer = null;
				scorer = testMgr().run(showErrorsOnlyElem().isSelected(),
											selectedTestCases(), selectedTests());
				logElem().setText(scorer.getLog().toString());
				scoreElem().setText(String.format("%d%%", Math.round(scorer.computeScoreAsPercent())));
				logElem().setCaretPosition(0);
				if (scorer.isPassing())
					setStatusColor(Color.black, Color.green, "PASSED");
				else
					setStatusColor(Color.black, Color.red, "FAILURES");
				finishThread();
			}
		}	
		
		class RefreshTask implements Runnable {
			@Override
			public void run() {
				while (running) {
					timerTicked();
					try {
						TimeUnit.MILLISECONDS.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}		
		
		List<Runnable> tasks = new ArrayList<Runnable>();
		tasks.add(new BackgroundTask());
		tasks.add(new RefreshTask());		
		
		this.e = Executors.newCachedThreadPool();
		//System.out.println("starting tasks");

		this.running = true;
		this.clearLog();
		this.updateUiStates();		
		for (Runnable eachTask: tasks)
			e.execute(eachTask);
		
		//System.out.println("shutting down tasks");		

	}

	/*public void clickedRun2() {
		this.startTimer(1000);
		AssignmentScorer scorer = null;
		synchronized (timer) {
			scorer = testMgr().run(this.selectedTestCases(), this.selectedTests());
			try {
				timer.wait(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		this.logElem().setText(scorer.getLog().toString());
		this.logElem().setCaretPosition(0);
		if (scorer.isPassing())
			this.setStatusColor(Color.black, Color.green, "PASSED");
		else
			this.setStatusColor(Color.black, Color.red, "FAILURES");
		this.stopTimer();
	}*/
	
	protected String conformTestLabel(String testLabel) {
		if (!this.hasOneTestCaseSelected() || !testLabel.contains("."))
			return testLabel;
		return testLabel.split("\\.")[1];
	}

	@Override
	protected void timerTicked() {
		String status = testMgr().currentTestLabel();
		status = this.conformTestLabel(status);
		String label = status.isBlank() ? "" : "Running: ";
		setStatusHighlighted(label + status); 		
	}

	//----------------------------------------------------
	//selections

	private List<String> selectedTestCases() {
		return this.testCasesElem().getSelectedValuesList();
	}

	private List<String> selectedTests() {
		return this.testsElem().getSelectedValuesList();
	}

	//===========================================================================
	//getting elements

	@SuppressWarnings("unchecked")
	private JList<String> testCasesElem() {
		return (JList<String>) this.elem("testCases");
	}

	@SuppressWarnings("unchecked")
	private JList<String> testsElem() {
		return (JList<String>) this.elem("tests");
	}

	private JTextArea logElem() {
		return (JTextArea) this.elem("log");
	}

	private JLabel statusElem() {
		return (JLabel) this.elem("status");
	}
	
	private JCheckBox showErrorsOnlyElem() {
		return (JCheckBox) this.elem("showErrorsOnly");
	}	
	
	private JLabel scoreElem() {
		return (JLabel) this.elem("score");
	}	
	
	private JButton selectAllCasesElem() {
		return (JButton) this.elem("selectAllCases");
	}

	private JButton selectAllTestsElem() {
		return (JButton) this.elem("selectAllTests");
	}

	private JButton runElem() {
		return (JButton) this.elem("run");
	}

	//===========================================================================

	@SuppressWarnings("unused")
	private void setStatusColor(Color foreColor, Color backColor, String label) {
		//setStatusHighlighted(label);
		JLabel status = this.statusElem();
		status.setText(label);
		status.setForeground(foreColor);
		status.setBackground(backColor);
		status.setVisible(true);
	}
	
	private void setStatusHighlighted(String label) {
		JLabel status = this.statusElem();
		status.setText(label);
		status.setBackground(null);		
		status.setForeground(Color.RED);
		status.setVisible(true);
	}	
	
	private void resetStatus() {
		JLabel status = this.statusElem();
		status.setText("READY");
		status.setForeground(null);
		status.setBackground(null);
	}
	
	protected void clearLog() {
		this.logElem().setText("");
	}

	//===========================================================================

	protected static UnitTestManagerIdea testMgr() {
		return UnitTestConfiguration.getTestManager();
	}

	//===========================================================================	

	static protected void prn(Object o) {
		System.out.println(o.toString());
	}

}
