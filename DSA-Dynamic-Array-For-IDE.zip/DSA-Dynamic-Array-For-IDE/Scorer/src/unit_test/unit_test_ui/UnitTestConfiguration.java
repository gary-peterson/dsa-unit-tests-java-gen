package unit_test.unit_test_ui;

import unit_test.unit_test_model.UnitTestManagerIdea;

public class UnitTestConfiguration {
	
	private static UnitTestManagerIdea TestManager;
		
	public static UnitTestManagerIdea getTestManager() {
		return TestManager;
	}

	public static void setTestManager(UnitTestManagerIdea testManager) {
		TestManager = testManager;
	}

}
