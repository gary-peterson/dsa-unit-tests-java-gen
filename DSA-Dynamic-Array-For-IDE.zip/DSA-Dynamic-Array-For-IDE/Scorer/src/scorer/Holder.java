package scorer;

class Holder<T> {
	
	public T value;

	public Holder(T newValue) {
		value(newValue);
	}

	public T value() {
		return this.value;
	}

	public void value(T newValue) {
		this.value = newValue;
	}
	
}