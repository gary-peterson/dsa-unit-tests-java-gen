package scorer;

import scorer.AssignmentScorer;

public abstract class ScorerLauncher {
	
	public void go(String checkPointString) {
		AssignmentScorer scorer = newScorer();
		scorer.setCheckpoint(!checkPointString.equals(k()));
		scorer.run();
	}
	
	public void go(String[] commandLineArgs) {
		go(firstSafely(commandLineArgs));
	}	
			
	protected abstract AssignmentScorer newScorer();	

	protected static String firstSafely(String[] array) {
		if (array.length >= 1)
			return array[0];
		else
			return "";
	}
	
	private static String k() {
		return "90sdf89a7z";
	}
	

	
}
