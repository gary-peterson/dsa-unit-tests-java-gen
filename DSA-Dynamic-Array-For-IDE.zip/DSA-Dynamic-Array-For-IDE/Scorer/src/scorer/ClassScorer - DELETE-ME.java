package scorer;

import static java.lang.System.out;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class ClassScorer extends MyObject implements ClassTest, ClassScorerInterface {

	//==================================================	
	// Ivars
	
	private List<MethodTest> methodTests;
	
	private Object testee;
	private Log
		log,
		exceptionLog;
	private String testTitle;
	private boolean scoring;
	private String testCaseName;
	private MethodTest currentTest;
	
	// Constructing
	public ClassScorer(String newTestTitle) {
		super();
		this.log = new Log("Test Log:");		
		this.exceptionLog = new Log("Exception Log:");
		setMethodTests(new ArrayList<MethodTest>());
		setErrors(new ArrayList<String>());
		this.testTitle = newTestTitle;
		this.scoring = true;
	}	

	// ===========================================================
	// Services

	public void setScoring(boolean scoring) {
		this.scoring = scoring;
	}	
	
	public void resetLogs() {
		this.log = new Log("Test Log:");		
		this.exceptionLog = new Log("Exception Log:");		
	}

	public void atTestSetMax(String testSelector, int max) throws Exception {
		// print("FOO " + testMethodWithTestSelector(testSelector).toString());
		MethodTest m = testMethodWithTestSelector(testSelector);
		//we allow subset of methods to be selected, so must have soft check here
		if (m == null)
			return;
			//throw new Exception("PointClassScorer>>atTestSetMax() -- testSelector not found -- " + testSelector);
		m.setMaxScore(max);
	}

	public void validate() throws Exception {
		/*
		 * Path path = Paths.get("MyLib.class"); if (!Files.exists(path)) throw new
		 * Exception(" ** ERROR ** File not found: " + path.toString() +
		 * " -- **See Assignment Instructions**");
		 */

		// COMMENTING OUT -- we run into problems in IDE's with this validation
		/*
		 * path = Paths.get(getTesteeClassName() + ".class"); if (!Files.exists(path))
		 * throw new Exception(" ** ERROR ** File not found: " + path.toString());
		 */
	}
	
	//==============================================================
	//Working...

	@SuppressWarnings("rawtypes") //Not using generics	
	public void basicRun(TestCase tester) throws Exception {
		validate();
		//if (getTesteeClass() == null)
		//	println("Note: Starting tests without testee class (may be by design)");
		// throw new Exception("** ERROR ** Class not found: " + getTesteeClassName());
		Class testerClass = tester.getClass();
		for (MethodTest methodTest : getMethodTests())
			if (methodTest.isRunnable()) {
				//System.out.println("testing: " + methodTest.getTesteeMethodName());
				this.currentTest = methodTest; 
				tester.beforeEach();
				runTest(methodTest, testerClass, tester);
				this.currentTest = null;				
			}
	}
	
	public void run(TestCase tester) {
		
		try {basicRun(tester);}
		catch(Error|Exception e) {
			Log exlog = this.exceptionLog;
			exlog.separator();
			exlog.println(e.toString());
			Throwable cause = e.getCause();
			if (cause != null) { 
				exlog
					.separator()
					.println("Details: " + cause.toString())
					.separator();
			}
		}
						
	}
	
	//==============================================================

	@SuppressWarnings("rawtypes") //Not using generics	
	private void runTest(MethodTest methodTest, Class testerClass, TestCase tester) {
		Method testMethod = null;
		String testSelector = methodTest.getTestSelector();

		//print("");
		//System.out.println("Starting Scoring For: " + methodTest.getTesteeMethodName());

		try {
			testMethod = firstMethodNamed(testSelector, testerClass);
		} catch (Exception ex) {
			addError(ex, ("Exception -- could not find test selector -- " + testSelector));
		}

		try {
			int timeoutAsMs;
			boolean finished;
	
			//two seconds -- we should make this dynamic 
			//e.g. ability to increase for large data testing
			timeoutAsMs = 1000 * 5;		
			//Process will terminate before you can debug
			//Uncomment the next line for debugging			
			timeoutAsMs = 1000 * 200; 
			
			finished = runTestWithTimeout(testMethod, tester, methodTest, timeoutAsMs);
			if (!finished) {
				//methodTest.reset();
				//methodTest.record(0, 1);

				//removing - redundant with "setAsFailed" below
				//methodTest.record(false, "Timeout");
				
				//methodTest.setMaxFailures(1);
				//methodTest.record(false, 1);
				//methodTest.addError("Exception Occurred");
				String error = "Operation timed out (infinite loop or other) in <" + testSelector + ">";
				//methodTest.setAsFailed(error);
				methodTest.setAsFailed(null);
				addError(error);
				println("");
				Exception ex = new Exception(error);
				logException("Timed Out", ex);
				//throw(ex);				
			}			
			//testMethod.invoke(tester, methodTest);
		} catch (Exception ex) {
			getExceptionLog().logException("Exception during test: " + testSelector, ex);
			throw(ex);
//			methodTest.reset();
//			methodTest.record(0, 1);
//			Throwable cause = ex.getCause();
//			StackTraceElement err = cause.getStackTrace()[0];
//			String errMsg = String.format("\"%s\" (%s line %d)", err.getMethodName(),
//											err.getFileName(), err.getLineNumber());
//			String label = String.format(MethodTest.exeptionErrorPrefix() + " test \"%s\"", testSelector); 
//			addError(ex, (label + " at " + errMsg));
//			Log exLog = this.getExceptionLog();
//			exLog
//				.println(label);
//			Throwable callStackSource = (cause != null) ? cause : ex;
//			callStackSource.printStackTrace(this.getExceptionLog().getStream());
//			exLog.cr();
		}
	}

	//====================================================================

	protected boolean runTestWithTimeout(
			Method aTestMethod
			, TestCase aTester
			, MethodTest aMethodTest
			, int timeoutAsMs)	{
		//Return true if ran okay, false if timed out
		ExecutorService executor = Executors.newSingleThreadExecutor();
		//out.printf("Executing test %s with %d millisecond timeout%n"
		//		, aMethodTest.getTestSelector(), timeoutAsMs);
		Future<Integer> future;
		future = executor.submit(new TestTask(aTestMethod, aTester, aMethodTest));
		boolean okay = false;

		try {
			//out.println("Starting Test With Timeout...");
			future.get(timeoutAsMs, TimeUnit.MILLISECONDS);
			//out.println("Test Task Result: " + result);
			//out.println("Finished Test With Timeout...");
			okay = true;
		} catch (Throwable ex) {
			future.cancel(true);
			//out.println("Operation Timed Out: ");
			okay = false;
		}

		//Cleanup
		executor.shutdownNow();
		//executor.awaitTermination();
		//awaitTerminationAfterShutdown(executor, aMethodTest);
		//Thread.currentThread().interrupt();
		
		//out.println("RESUMING");

		return okay;
	}
	
	//https://www.baeldung.com/java-executor-wait-for-threads
	public void awaitTerminationAfterShutdown(ExecutorService threadPool, MethodTest mt) {
		out.println("STARTED -- awaitTerminationAfterShutdown " + mt.getTestSelector());
	    threadPool.shutdown();
	    try {
	        if (!threadPool.awaitTermination(1, TimeUnit.SECONDS)) {
	            threadPool.shutdownNow();
	        }
	    } catch (InterruptedException ex) {
	    	out.println("interrupting thread");
	        threadPool.shutdownNow();
	        Thread.currentThread().interrupt();
	    }
		out.println("FINISHED -- awaitTerminationAfterShutdown " + mt.getTestSelector());	    
	}	
	
	void shutdownAndAwaitTerminationZ(ExecutorService pool) {
	    pool.shutdown(); // Disable new tasks from being submitted
	    try {
	        // Wait a while for existing tasks to terminate
	        if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
	            pool.shutdownNow(); // Cancel currently executing tasks
	            // Wait a while for tasks to respond to being cancelled
	            if (!pool.awaitTermination(60, TimeUnit.SECONDS))
	                System.err.println("Pool did not terminate");
	        }
	    } catch (InterruptedException ie) {
	        // (Re-)Cancel if current thread also interrupted
	        pool.shutdownNow();
	        // Preserve interrupt status
	        Thread.currentThread().interrupt();
	    }
	}	
	
	//====================================================================	
	
	public void setTestMethodsFrom(String[][] testData) {
		/*
		 * modelSelector, testSelector { {"doubleValue", "test_doubleValue"}, {"triple",
		 * "test_triple"} }
		 */
		for (String[] row : testData)
			addTestMethodNamed(row[0], row[1]);
	}
	
	public void setTestMethodsFrom(String[] testNames) {
		for (String eachTestName: testNames)
			addTestMethodNamed(eachTestName, eachTestName);
	}	

	public void setAllMaxScores(int max) {
		for (MethodTest mt : getMethodTests())
			mt.setMaxScore(max);
	}

	private void addTestMethodNamed(String modelSelector, String testSelector) {
		MethodTest methodTest = new MethodTest(this, modelSelector, testSelector);
		getMethodTests().add(methodTest);
	}

	public MethodTest testMethodNamed(String methodName) {
		for (MethodTest m : getMethodTests())
			if (m.hasName(methodName))
				return m;
		return null;
	}

	public MethodTest testMethodWithTestSelector(String testSelector) {
		for (MethodTest m : getMethodTests())
			if (testSelector == m.getTestSelector())
				return m;
		return null;
	}

	public void printDetailed() {
		println(this.getClass().getSimpleName());

		for (MethodTest mt : getMethodTests())
			println(mt.getTesteeMethodName());
	}

	public int nonRunnableCount() {
		// gpimprove -- countFor
		int count = 0;
		for (MethodTest mt : getMethodTests())
			if (!mt.isRunnable())
				count++;
		return count;
	}
	
	public void printHeaderOn(Log strm) {
		strm.println("Test Case Subject: " + this.getTestTitle());
		strm.println("Test Case Class: " + this.testCaseName);		
		if (this.scoring)
			strm.printf("%s%n", getSummary().toString());		
	}
	
	public void printSubtestSummaryOn(Log strm) {
		strm.printf("%nIndividual test results:%n");
		strm.println("");
		for (MethodTest mt : getMethodTests())
			if (mt.isRunnable())
				strm.println(mt.asDisplayString(this.scoring));
		strm.println("");

		if (nonRunnableCount() > 0) {
			strm.println("------");
			strm.println("These tests were not runnable (see \"ERROR LISTING\" below):");
			strm.println("");
			for (MethodTest mt : getMethodTests())
				if (!mt.isRunnable())
					strm.println(mt.asDisplayString(this.scoring));
		}

		//Seems redudant (we catch these in log)
		//TODO -- don't need errors ivar
		//printErrorsOn(strm);

		/*log().println("-------");
		log().println(this.getTestTitle());
		log().println("Score: " + score + " of " + max);*/
		// print("Percent: " + percentPassing + "%\n");
	}

	private int getMax() {
		int sum = 0;
		for (MethodTest mt : getMethodTests())
			sum += mt.getMaxScore();
		return sum;
	}

	private int getScore() {
		int sum = 0;
		for (MethodTest mt : getMethodTests())
			sum += mt.getScore();
		return sum;
	}
	
	protected void printErrorsOn(Log strm) {
		ArrayList<MethodTest> list = methodTestsWithErrors();
		if (list.size() == 0)
			return;
		strm.println("-------------");
		strm.println("ERROR LISTING:\n");
		super.printErrors();
		for (MethodTest mt : list)
			mt.printErrors();
		strm.println("");
	}

	// Helpers

	public Method firstMethodNamed(String methodName) throws Exception {
		return firstMethodNamed(methodName, getTesteeClass());
	}

	@SuppressWarnings({"rawtypes", "unchecked"}) //Not using generics	
	public Method firstMethodNamed(String methodName, Class target) throws Exception {
		// NOTE WELL -- overloaded NOT supported by this method
		// NOTE WELL Java's Class>>#getMethod()only gets public methods
		// However this method will find any implemented method on target class
		if (target == null)
			return null;
		Method[] methods;
		methods = target.getDeclaredMethods();
		for (Method m : methods)
			if (m.getName().equals(methodName))
				return m;
		//getMethod allows inheritance

		//gpToDo -- 'MethodTest' is hard coded here
		Class[] paramTypes = null; 
		if (methodName.startsWith("test_"))
			paramTypes = new Class[] {MethodTest.class};
		else
			paramTypes = new Class[] {};			
		Method m = target.getMethod(methodName, paramTypes);		
		if (m != null) return m;
		throw new Exception("Did not find method named -- " + methodName);
	}

	public ArrayList<MethodTest> methodTestsWithErrors() {
		ArrayList<MethodTest> a = new ArrayList<MethodTest>();
		// if (true) return getMethodTests();
		for (MethodTest mt : getMethodTests())
			if (mt.hasErrors())
				a.add(mt);
		return a;
	}

	@Override
	public void logException(String label, Throwable throwable) {
		this.getExceptionLog().logException(label, throwable);
	}
	
//	@Override
//	public void print() {
//		this.printSummary();
//		this.log.print();
//		this.exceptionLog.print();
//	}
	
	public void printSummaryOn(Log strm) {
		this.printHeaderOn(strm);		
		printSubtestSummaryOn(strm);
	}	
	
	public void printOn(Log strm) {
		strm.thickSeparator();
		this.printHeaderOn(strm);		
		this.printSubtestSummaryOn(strm);
		this.basicPrintLogOn(strm);
	}
	
	@Override	
	public boolean hasLogContent() {
		return log().getSize() > 0 || exceptionsOccured();
	}
	
	@Override
	public void printLogOn(Log strm) {
		//strm.separator();
		if (!hasLogContent()) return;
		//strm.printf("Log For \"%s\" (%s)\n", this.getTestTitle(), this.testCaseName);
		strm.printf("Log For test case \"%s\"\n", this.testCaseName);
		strm.printf("%s%n", getSummary().toString());		
		this.basicPrintLogOn(strm);
	}
	
	private void basicPrintLogOn(Log strm) {
		Log log = log();
		if (log.getSize() > 0) {
			log.setContents(log.getContentsString().replaceAll("\\s+$", ""));
			strm
				.cr().separator()
				.print(log)
				.cr();
		}
		if (exceptionsOccured()) {
			strm
				.cr()
				.separator()
				.print(getExceptionLog());
		}
	}	
		
	public void printExceptionsOn(Log strm) {
		if (exceptionsOccured()) {
			getExceptionLog().setLabel("Exception Log for: " + this.getTestTitle());
			strm
				.cr()
				.separator()
				.print(getExceptionLog())
				.cr();			
		}		
	}	
	
	public boolean exceptionsOccured() {
		return this.getExceptionLog().getSize() > 0;
	}	
	
	//==================================================	
	// Accessors	
	
	public Log getExceptionLog() {
		return exceptionLog;
	}

	public String getTestTitle() {
		return testTitle;
	}

	@Override
	public Log getLog() {
		return this.log;
	}
	
	//alias
	protected Log log() {
		return this.log;
	}	

	public String getTesteeClassName() {
		return this.getTesteeClass().getSimpleName();
	}

	@SuppressWarnings({"rawtypes"}) //Not using generics	
	public Class getTesteeClass() {
			return 
				(this.getTestee() != null) ? 
					this.getTestee().getClass() : null;
	}

	@Override
	public Object getTestee() {
		return this.testee;
	}

	public List<MethodTest> getMethodTests() {
		return this.methodTests;
	}

	public void setTestee(Object value) {
		this.testee = value;
	}

	public void setMethodTests(ArrayList<MethodTest> value) {
		this.methodTests = value;
	}
	
	public int getScoreAsPercent() {
		if (getMax() == 0) return 0;
		double percent = 100.0 * getScore() / getMax();
		return (int)Math.round(percent);
		}
	
	public ScoreSummary getSummary() {
		return new ScoreSummary(getTestTitle(), getScore(), getMax());
	}

	@Override
	public void filterToBest(int useBestCount) {
		List<MethodTest> sorted = methodTestsSortedByScore();
		Collections.reverse(sorted);
		this.methodTests = 
			sorted.subList(0, Math.min(useBestCount, sorted.size()));
		//Now sort best by name for cosmetics		
		this.methodTests = methodTestsSortedByName();		
	}
	
	private List<MethodTest> methodTestsSortedByScore() {
		//By score increasing
		List<MethodTest> sorted = new ArrayList<>(this.methodTests);
		sorted.sort((m1, m2) -> Integer.valueOf(m1.getScore()).compareTo(m2.getScore()));
		return sorted;
	}
	
	private List<MethodTest> methodTestsSortedByName() {
		//By name alpha
		List<MethodTest> sorted = new ArrayList<>(this.methodTests);
		sorted.sort((m1, m2) -> m1.getTesteeMethodName().compareTo(m2.getTesteeMethodName())); 
		return sorted;
	}

	@Override
	public int testCount() {
		return this.getMethodTests().size();
	}

	@Override
	public boolean isPassing() {
		return this.getScoreAsPercent() == 100;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	
	//-----------------------------------------------------------------
	
	@Override
	public String currentTestLabel() {
		if (this.currentTest != null)
			return this.testCaseName + "." + this.currentTest.getTesteeMethodName();
		//return "Nope--ClassScorer>>currentTestLabel";
		return "";
	}	

}

// ----------------------------
