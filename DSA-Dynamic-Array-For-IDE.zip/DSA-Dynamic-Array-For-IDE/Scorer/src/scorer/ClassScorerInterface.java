package scorer;

interface ClassScorerInterface
{
	Object getTestee();
	void run(TestCase tester);
	Log getLog();
	//void setLog(Log aLog);	
	void logException(String label, Throwable exception);
	ScoreSummary getSummary();
	void printSummaryOn(Log strm);	
	void printOn(Log strm);
	void printLogOn(Log strm);	
	void printExceptionsOn(Log strm);
	void filterToBest(int useBestCount);
	void resetLogs();
	int testCount();
	boolean hasLogContent();
	boolean isPassing();

	void setScoring(boolean scoring);
	String currentTestLabel();	
}

