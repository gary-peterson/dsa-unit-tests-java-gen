package scorer;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AssignmentScorer extends AggregateScorer {
	private boolean passed;
	private boolean checkpoint;
	private List<AbstractScorer<TestSpec>> scorers;
	private String title;
	private int useBestCount;		//e.g. if 2, means use best 2
	private AbstractScorer<TestSpec> currentTestCase;

	public void setUseBestCount(Integer useBestCount) {
		this.useBestCount = useBestCount;
	}

	public String getTitle() {
		return title;
	}

	public boolean isCheckpoint() {
		return checkpoint;
	}

	public String getLabel() {
		if (isCheckpoint())
			return "Checkpoint";
		else
			return "Scorer";
	}

	public void setCheckpoint(boolean checkpoint) {
		this.checkpoint = checkpoint;
	}

	public boolean isPassed() {
		return passed;
	}
	
	public boolean hasOneTestCase() {
		return this.scorers.size() == 1;
	}
	
	// ========================================================	

	public AssignmentScorer(String newTitle, int totalPoints, List<AbstractScorer<TestSpec>> newScorers) {
		super(totalPoints);
		this.title = newTitle;
		this.scorers = newScorers;
		this.passed = false;
		this.checkpoint = false;
		this.useBestCount = -1;
	}

	// ========================================================

	public boolean isPassing() {
		//all passing
		for (AbstractScorer<TestSpec> each: this.scorers)
			if (!each.isPassing())
				return false;
		return true;
	}
	
	public double computeScoreAsPercent() {
		int 
			possible = 0,
			score = 0;
		for (AbstractScorer<TestSpec> eachScorer: this.scorers) {
			TotalScoreSummary scoreSummary = eachScorer.getSummary();
			possible += scoreSummary.getPossiblePoints();
			score += scoreSummary.getPoints();			
		}
		if (possible == 0) return 0;
		return 100.0 * ((double)score / possible);
	}	

	public ScoreSummary findLowestScore(List<TotalScoreSummary> summaries) {
		ScoreSummary lowest = null;
		for (ScoreSummary summary : summaries)
			if (lowest == null || (summary.getScorePercent() < lowest.getScorePercent()))
				lowest = summary;
		return lowest;
	}

	public void printScoringSummary(List<TotalScoreSummary> subSummaries, TotalScoreSummary totalSummary,
			int totalPoints) {
		if (isCheckpoint())
			printCheckpointSummary(subSummaries, totalSummary, totalPoints);
		else if (this.isShowPoints())
			super.printScoringSummary(subSummaries, totalSummary, totalPoints);
	}

	//gpneeds thought why are we not using totalPoints 
	public void printCheckpointSummary(List<TotalScoreSummary> subSummaries, TotalScoreSummary totalSummary,
			@SuppressWarnings("unused") int totalPoints) {

		log().thickSeparator();
		log().printf("%s%n%n", getLabel());
		log().printf("Checked:%n");
		for (ScoreSummary eachSummary : subSummaries)
			log().printf("\t%s%n", eachSummary.getLabel());

		log().cr();
		//For checkpoints, we primarily use getPointsPercent(), not getScorePercent()
		/*
		 * e.g. the two percents score/points can be vary different
		 * Points is the one we want because if includes problem weights
		 * HashLookupPrototype  -- Checks: 100 of 100 (100%) -- for 80 of 80 Points
		 * HashLookup           -- Checks: 0 of 300 (0%) -- for 0 of 35 Points
		 */
		int percent = totalSummary.getPointsPercent();
		int threshold = 70;
		log().printf("Checkpoint Threshold: %d%%%n", threshold);
		this.passed = percent >= threshold;
		if (this.passed)
			log().printf("Checkpoint PASSED%n");
		else {
			log().printf("Checkpoint FAILED%n");
			log().print("Suggested Focus Area: " + findLowestScore(subSummaries).getLabel());
		}
	}

	public void run() {
		try {
			basicRun();
		} catch (Error ex) {
			if (getPreDiagnosticsLog() != null)
				log().print(this.getPreDiagnosticsLog());
			log()
				.println(getLabel() + " FAILED")
				.logException("Startup", ex);
			writeCriticalErrorReport();
		}
	}

	protected void writeCriticalErrorReport() {
		//Write final report
		log().setLabel(getTitle());
		log().printToConsole();
	}

	public void basicRun() {
		/*
		 * spec is a TestSpec
		 */
		TotalScoreSummary overallSummary = new TotalScoreSummary("Overall Testing Score", 0);
		List<TotalScoreSummary> summaries = new ArrayList<>();
		List<AbstractScorer<TestSpec>> scorers = new ArrayList<>();
		TotalScoreSummary subSummary;

		//(new Log("")).starsSeparator().printToConsole();
		//preScore(); trying this in log area

		for (AbstractScorer<TestSpec> scorer: this.scorers) {
			scorers.add(scorer);
			this.currentTestCase = scorer;			
			scorer.run();
			this.currentTestCase = null;			
			subSummary = scorer.getSummary();
			summaries.add(subSummary);
			//overallSummary.increaseBy(subSummary);
		}
		
		//If we have best S of N, then select S now
		if (this.useBestCount > 0) {
				Stream<TotalScoreSummary> stream = summaries.stream();
				//reverse sort highest to lowest
				stream = stream.sorted((summ1, summ2) 
						-> -Integer.compare(summ1.getScore(), summ2.getScore()));
				summaries = stream.collect(Collectors.toList());
				//bestOf
				summaries = summaries.subList(0, this.useBestCount);
		}
		
		for (TotalScoreSummary eachSummary: summaries)
			overallSummary.increaseBy(eachSummary);

		overallSummary.setPointsFrom(summaries);
		
		printReport(overallSummary, summaries);

		//We need this exit as we have model in separate thread
		//Which does not [really] terminate when sent "shutdown" or "shutdownNow"
		//TODO??
		if (!this.isHeadfull())		
			System.exit(0);
	}
	
	private void printReport(TotalScoreSummary overallSummary,
								List<TotalScoreSummary> summaries) {
		//Write final report
		Log report = new Log(getTitle());
		
		if (this.isShowErrorsOnly()) {
			report.starsSeparator(1).println("LOGS");
			if (!preScore(report))
				report.cr();
			for (AbstractScorer<TestSpec> eachScorer : scorers)
				if (eachScorer.hasLogContent()) {
					report.cr().thickSeparator().cr();				
					eachScorer.printLogOn(report);
				}	
			report.cr().thickSeparator();
			printScoringSummaryTo(report, summaries, overallSummary, getMaxPoints());
			placeReport(report);
			return;
		}
		
		
		printScoringSummaryTo(report, summaries, overallSummary, getMaxPoints());
		
		if (getPreDiagnosticsLog() != null)
			report.print(this.getPreDiagnosticsLog());
		report.print(getLog());

		if (!isCheckpoint()) {
			if (!hasOneTestCase() && this.isShowPoints())
				report.cr().starsSeparator(4);
			if (!hasOneTestCase())
				report.cr().println("TEST CASE SUMMARIES").cr();
			report.separator().cr();			
			int count = 0, sz = scorers.size();
			for (AbstractScorer<TestSpec> eachScorer : scorers) {
				eachScorer.printSummaryOn(report);
				if (++count < sz)
					report.separator().cr();
			}
			if (!this.hasOneTestCase())
				report.starsSeparator(3);
			report.starsSeparator(1).println("LOGS");
			if (!preScore(report))
				report.cr();
			for (AbstractScorer<TestSpec> eachScorer : scorers)
				if (eachScorer.hasLogContent()) {
					report.cr().thickSeparator().cr();				
					eachScorer.printLogOn(report);
				}
			report.cr();
		}
				
		if (this.isShowPoints())
			report.starsSeparator(4).cr();		
		printScoringSummaryTo(report, summaries, overallSummary, getMaxPoints());  

		placeReport(report);
	
	}

	
	private void placeReport(Log report) {
		if (!this.isHeadfull())
			report.printToConsole();
		else
			this.log().print(report);			
	}
	

	//gpneedsthought why are we not using maxPoints
	private void printScoringSummaryTo(
			Log aReport,
			List<TotalScoreSummary> summaries, 
			TotalScoreSummary overallSummary,
			@SuppressWarnings("unused") int maxPoints) {
		Log oldLog = getLog();
		this.setLog(new Log(""));
		printScoringSummary(summaries, overallSummary, getMaxPoints());
		aReport.print(this.getLog());
		//Restore
		this.setLog(oldLog);
	}

	private boolean preScore(Log l) {
		Log tempLog = new Log("");
		//tempLog.separator();
		boolean okay = checkTesteeConstruction(tempLog);
		if (!okay) {
			l
				//.separator()
				.print(tempLog);
		}
		return okay;
	}

	private boolean checkTesteeConstruction(Log log) {
		//return true if okay
		log.cr().p("Checking Constructability (Smoke Test)").cr();
		int count = 0;
		boolean hasError = false;
		for (AbstractScorer<TestSpec> eachScorer : this.scorers) {
			String postfix, annotation;
			postfix = String.format("using -- %s", eachScorer.getConstructTesteeSnippet());
			boolean isConstructable = eachScorer.isConstructable();
			if (!isConstructable) hasError = true;
			annotation = isConstructable ? "okay (constructable) -- " + postfix
					: "ERROR -- could not construct -- " + postfix;
			log.print(eachScorer.getLabel() + " -- " + annotation);
			if (++count < this.scorers.size()) log.cr();
		}
		return !hasError;
	}
	
	public String currentTestLabel() {
		if (this.currentTestCase != null)
			return this.currentTestCase.currentTestLabel();
		//return "Nope--AssignmentScorer>>currentTestLabel";
		return "";
	}
	

} //end class
