package scorer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public class ObjectTool {
	
	public static Object performMethod(Method m, Object target, Object... args) throws Exception
	{
		//Perform selector with args for target
		Object returnValue = null;
		try { returnValue = m.invoke(target, args); }
		catch(Exception ex) {
			throw ex;
		}
		return returnValue;
	}
	
	public static Object performMethod(String methodName, Object target, Object... args) throws Exception
	{
		//Perform selector with args for target
		return performMethod(methodName, target, args);
	}
	
	@SuppressWarnings("rawtypes")
	public static Object performMethod(String methodName, Object target
										, Class[] methodParamTypes, Object... args) throws Exception
	{
		//Perform selector with args for target
		Method m = ClassTool.findMethod(methodName, target.getClass(), methodParamTypes);
		return performMethod(m, target, args);
	}		
	
	public static <T> List<T> collectOld(Function<T, T> fct, List<T> list) {
		//This is problematic in case when "list" is immutable
		//as a List is when sender uses (common) Arrays.asList()
		List<T> collector = ClassTool.newInstance(list);		
		Stream<T> strm = list.stream().map(fct);
		strm.forEach(str -> collector.add(str));
		return collector;
	}		
	
	public static <T> List<T> collect(Function<T, T> fct, List<T> list) {
		//collect2 or collectIntoArrayList
		//Assumption: ArrayList is okay to use
		List<T> collector = new ArrayList<>();		
		Stream<T> strm = list.stream().map(fct);
		strm.forEach(str -> collector.add(str));
		return collector;
	}	
	
	public static <T> List<T> collect(Function<T, T> fct, List<T> list, List<T> collector) {
		Stream<T> strm = list.stream().map(fct);
		strm.forEach(str -> collector.add(str));
		return collector;
	}	
	
}
