package tests_cases;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import linearpub.DynamicList;
import scorer.AbstractScorer;
import scorer.TestSpec;
import unit_test.unit_test_model.UnitTestManager;

public class DynamicListTestSuite<T> extends UnitTestManager {
	
	private Supplier<DynamicList<T>> emptyListGenerator;	
	private String constructionSnippet;
	
	//--------------------------------------------------------
	
	public DynamicListTestSuite(Supplier<DynamicList<T>> anEmptyListGenerator,
								String aConstructionSnippet) {
		this(false);
		this.emptyListGenerator = anEmptyListGenerator;
		this.constructionSnippet = aConstructionSnippet;
	}	
	
	public DynamicListTestSuite(boolean aShouldScore) {
		super(aShouldScore);
	}
	
	//--------------------------------------------------------

	@Override	
	public List<Class<?>> testCases() {
		List<Class<?>> list = new ArrayList<>();
		list.add(EmptyList_Tests.class);
		list.add(OneElement_Tests.class);
		list.add(ManyElements_Tests.class);
		list.add(AddingInserting_Tests.class);
		list.add(Removing_Tests.class);
		list.add(LoadTests_Tests.class);		
		return list;
	}	

	@Override	
	public List<String> testCaseNames() {
		return testCases().stream()
			.map(testCase -> testCase.getSimpleName())
			.collect(Collectors.toList());
	}

//	private static <T> Supplier<DynamicList<T>> emptyLLGenerator() {
//		return () -> LinkedListFactory.newList();
//	}
//	
//	private static String constructLLUnitSnippet() {
//		return "LinkedListFactory.newList()";
//	}

	@SuppressWarnings("unchecked")
	@Override
	public AbstractScorer<TestSpec> newTestCase(Class<?> testCase) throws Exception {
		Constructor<?> constructor;
		Abstract_DynamicList_TestCase<T> scorer;		
		constructor = testCase.getConstructor();
		scorer = (Abstract_DynamicList_TestCase<T>)constructor.newInstance();			
		scorer.setConstructUnitSnippet(this.constructionSnippet);
		scorer.setEmptyListGenerator(this.emptyListGenerator);
		return scorer;
	}	

	//---------------------------------------------------------------
	//Run All
	
	public void runAll() {
		run(false, this.testCaseNames(), new ArrayList<>());
	}
	
	public void runAll(boolean headFull, boolean shouldScore) {
		setHeadfull(headFull);
		setShouldScore(shouldScore);
		runAll();
	}	
	
	public static <U> void runAllTestCases(boolean b) {
		DynamicListTestSuite<U> mgr = new DynamicListTestSuite<>(b);
		mgr.setHeadfull(false);
		mgr.runAll();
	}	
	
	public static void main(String[] args) {
		String[] array = args;
		array = new String[]{"y"};
		DynamicListTestSuite.runAllTestCases(array.length > 0 ? array[0].toLowerCase().equals("y") : false);
	}
	
}
